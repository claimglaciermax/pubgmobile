

function go_spin() {
    $('.lenzzbutton').hide()
    $('.putarkan').on('click', gaskeun)
    setTimeout(gaskeun, 900)
}
const hadiah = {
    0: 'img/reward/1.jpg',
    1: 'img/reward/2.jpg',
    2: 'img/reward/3.jpg',
    3: 'img/reward/4.jpg',
    4: 'img/reward/5.jpg',
    5: 'img/reward/6.jpg',
    6: 'img/reward/7.jpg',
    7: 'img/reward/8.jpg',
    8: 'img/reward/9.jpg',
	9: 'img/reward/10.jpg',
};

const jumlah_hadiah = 10;
const minimal_lompat = 10; 
let lenzzgift = -1;
let lompat = 0;
let kecepatan = 10;
let waktu = 0;
let hadiahnya = -1;

  function putarkan() {
    $('[data-order="' + lenzzgift + '"]').removeClass('border_hadiah')
    lenzzgift += 1
    lenzzgift > jumlah_hadiah - 1 && (lenzzgift = 0)
    $('[data-order="' + lenzzgift + '"]').addClass('border_hadiah')
    var _0x153fba = document.getElementById('audioItem')
    _0x153fba.currentTime = 0.4
    _0x153fba.duration = 0.1
    _0x153fba.play()
  }
  function acakHadiah() {
    return Math.floor(Math.random() * jumlah_hadiah)
  }
  function pengaturanWaktu() {
    lompat += 1
    putarkan()
    if (lompat > minimal_lompat + 5 && hadiahnya === lenzzgift) {
      clearTimeout(waktu)
      $('[data-order="' + lenzzgift + '"]').addClass('box-shadow')
      var _0x2fa52b = document.getElementById('audioStop')
      _0x2fa52b.play()
      setTimeout(function () {
        $('.itemReward_confirmation').fadeIn()
      }, 900)
      var _0x2fa52b = document.getElementById('audioPopup')
      setTimeout(function () {
        document.getElementById('audioPopup').play()
        console.log('')
      }, 900)
      $('.gift_img').attr('src', hadiah[lenzzgift])
      setTimeout(function () {}, 0)
      hadiahnya = -1
      lompat = 0
    } else {
      if (lompat < minimal_lompat) {
        kecepatan -= 100
      } else {
        if (lompat === minimal_lompat) {
          const _0x4c7be8 = acakHadiah()
          hadiahnya = _0x4c7be8
        } else {
          lompat > minimal_lompat + 12 && hadiahnya === lenzzgift
            ? (kecepatan += 100)
            : (kecepatan += 100)
        }
      }
      kecepatan < 300 && (kecepatan = 100)
      waktu = setTimeout(pengaturanWaktu, kecepatan)
    }
  }
  function gaskeun() {
    lompat = 0
    kecepatan = 100
    hadiahnya = -1
    pengaturanWaktu()
  }
  $(document).ready(() => {
    $('.putarkan').on('click', gaskeun)
  })